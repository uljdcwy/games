module.exports = {
	transpileDependencies: ['vuetify'],
	pluginOptions: {
		electronBuilder: {
			nodeIntegration: true,
			preload: './src/preload.js',
			externals: ['knex', 'sqlite3'],
			builderOptions: {
				"extraResources": {
					from: "./Services",
					to: "Services"
				},
				"appId": "",
				"productName": "智能实时消费系统",
				"copyright": "",
				"win": {
					"icon": "./public/logo.ico",
					"target": [{
						"target": "nsis",
						"arch": [
							"ia32"
						]
					}]
				},
				"nsis": {
					"oneClick": true,
					"allowElevation": true,
					"installerIcon": "./public/logo.ico",
					"uninstallerIcon": "./public/logo.ico",
					"installerHeaderIcon": "./public/logo.ico",
					"createDesktopShortcut": true,
					"createStartMenuShortcut": true,
					"shortcutName": "智能实时消费系统"
				},
				"directories": {
					"output": "./dist"
				},
			}
		}
	}
}
