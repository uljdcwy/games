import VUE from "vue";

export const OperLogin = (data) => {
	return VUE.http.post('Oper/Login', data);
};

export const OperGetList = (data) => {
	return VUE.http.post('Oper/GetList', data);
};

export const OperAdd = (data) => {
	return VUE.http.post('Oper/Add', data);
};

export const OperRemove = (data) => {
	return VUE.http.post('Oper/Remove', data);
};

export const OperUpdate = (data) => {
	return VUE.http.post('Oper/Update', data);
};

export const RoleAdd = (data) => {
	return VUE.http.post('Role/Add', data);
};

export const RoleUpdate = (data) => {
	return VUE.http.post('Role/Update', data);
};

export const RoleRemove = (data) => {
	return VUE.http.post('Role/Remove', data);
};

export const RoleGetList = (data) => {
	return VUE.http.post('Role/GetList', data);
};

export const AreaAdd = (data) => {
	return VUE.http.post('Area/Add', data);
};

export const AreaUpdate = (data) => {
	return VUE.http.post('Area/Update', data);
};

export const AreaGetList = (data) => {
	return VUE.http.post('Area/GetList', data);
};

export const AreaRemove = (data) => {
	return VUE.http.post('Area/Remove', data);
};

export const DeviceUpdate = (data) => {
	return VUE.http.post('Device/Update', data);
};

export const DeviceAdd = (data) => {
	return VUE.http.post('Device/Add', data);
};

export const DeviceGetList = (data) => {
	return VUE.http.post('Device/GetList', data);
};

export const DeviceDelete = (data) => {
	return VUE.http.post('Device/Delete', data);
};

export const apiupload = (data) => {
	return VUE.http.post('api/upload', data);
};

export const UserAdd = (data) => {
	return VUE.http.post('User/Add', data);
};

export const UserUpdate = (data) => {
	return VUE.http.post('User/Update', data);
};

export const UserDelete = (data) => {
	return VUE.http.post('User/Delete', data);
};

export const UserRecharge = (data) => {
	return VUE.http.post('User/Recharge', data);
};

export const UserLostChannge = (data) => {
	return VUE.http.post('User/LostChannge', data);
};

export const UserChanngeCard = (data) => {
	return VUE.http.post('User/ChanngeCard', data);
};

export const UserGetList = (data) => {
	return VUE.http.post('User/GetList', data);
};

export const DiscountPackageAdd = (data) => {
	return VUE.http.post('DiscountPackage/Add', data);
};

export const DiscountPackageUpdate = (data) => {
	return VUE.http.post('DiscountPackage/Update', data);
};

export const DiscountPackageGetList = (data) => {
	return VUE.http.post('DiscountPackage/GetList', data);
};

export const DiscountPackageBindUser = (data) => {
	return VUE.http.post('DiscountPackage/BindUser', data);
};

export const DiscountPackageCancelBindUser = (data) => {
	return VUE.http.post('DiscountPackage/CancelBindUser', data);
};

export const CancellationRecordGetList = (data) => {
	return VUE.http.post('CancellationRecord/GetList', data);
};

export const LostRecordGetList = (data) => {
	return VUE.http.post('LostRecord/GetList', data);
};

export const ConsumeRecordGetList = (data) => {
	return VUE.http.post('ConsumeRecord/GetList', data);
};

export const ChanngeCardRecordGetList = (data) => {
	return VUE.http.post('ChanngeCardRecord/GetList', data);
};

export const RechargeRecordGetList = (data) => {
	return VUE.http.post('RechargeRecord/GetList', data);
};

export const DaySumRecordGetList = (data) => {
	return VUE.http.post('DaySumRecord/GetList', data);
};

export const DeviceReDownLoadFace = (data) => {
	return VUE.http.post('Device/ReDownLoadFace', data);
};

export const sysTestDBConnect = (data) => {
	return VUE.http.post('sys/TestDBConnect', data);
};

export const sysCreateDB = (data) => {
	return VUE.http.post('sys/CreateDB', data);
};

export const TaskFaceSyncGetList = (data) => {
	return VUE.http.post('Task/FaceSync/GetList', data);
};

export const TaskFaceSyncDeleteAll = (data) => {
	return VUE.http.post('Task/FaceSync/DeleteAll', data);
};

export const TaskFaceSyncDelete = (data) => {
	return VUE.http.post('Task/FaceSync/Delete', data);
};

export const sysCheckAuth = (data) => {
	return VUE.http.post('sys/CheckAuth', data);
};

export const sysGetSN = (data) => {
	return VUE.http.post('sys/GetSN', data);
};