import Vue from "vue";
import VueRouter from "vue-router";
import VueMeta from "vue-meta";
import store from "./../store/index";

Vue.use(VueRouter);
Vue.use(VueMeta);

import component from "../view/component.vue";
import index from "../view/index.vue";
import userManagement  from "../view/userManagement.vue";
import globalSettings  from "../view/globalSettings.vue";
import basicSettings  from "../view/basicSettings.vue";
import regionalInformationManagement  from "../view/regionalInformationManagement.vue";
import managementCard  from "../view/managementCard.vue";
import personInfoManage  from "../view/personInfoManage.vue";
import setAcquisition  from "../view/setAcquisition.vue";
import cardReadingInformation  from "../view/cardReadingInformation.vue";
import ImportPersonnelData  from "../view/ImportPersonnelData.vue";
import consumerMachine  from "../view/consumerMachine.vue";
import addRechargePackage  from "../view/addRechargePackage.vue";
import userLogoutRecord  from "../view/userLogoutRecord.vue";
import cardLossRecord  from "../view/cardLossRecord.vue";
import consumptionRecord  from "../view/consumptionRecord.vue";
import getStatisticalReports  from "../view/getStatisticalReports.vue";
import cardReplacementRecord  from "../view/cardReplacementRecord.vue";
import userRechargeRecordTable  from "../view/userRechargeRecordTable.vue";
import personFaceTask  from "../view/personFaceTask.vue";

const routes = [{
		path: "",
		redirect: "/index",
	},{
		path: "/index",
		name: "index",
		component: component,
		redirect: '/consumerMachine/consumerMachine',
		children: [
			{
				path: "/index/index",
				name: "permissionGroupName",
				component: index,
			},
			{
				path: "/personFaceTask/personFaceTask",
				name: "personFaceTask",
				component: personFaceTask,
			},
			{
				path: "/userManagement/userManagement",
				name: "userManagement",
				component: userManagement,
			},
			{
				path: "/basicSettings/basicSettings",
				name: "basicSettings",
				component: basicSettings,
			},
			{
				path: "/globalSettings/globalSettings",
				name: "globalSettings",
				component: globalSettings,
			},
			{
				path: "/regionalInformationManagement/regionalInformationManagement",
				name: "regionalInformationManagement",
				component: regionalInformationManagement,
			},
			{
				path: "/managementCard/managementCard",
				name: "managementCard",
				component: managementCard,
			},
			{
				path: "/personInfoManage/personInfoManage",
				name: "personInfoManage",
				component: personInfoManage,
			},
			{
				path: "/setAcquisition/setAcquisition",
				name: "setAcquisition",
				component: setAcquisition,
			},
			{
				path: "/ImportPersonnelData/ImportPersonnelData",
				name: "ImportPersonnelData",
				component: ImportPersonnelData,
			},
			{
				path: "/cardReadingInformation/cardReadingInformation",
				name: "cardReadingInformation",
				component: cardReadingInformation,
			},
			{
				path: "/consumerMachine/consumerMachine",
				name: "consumerMachine",
				component: consumerMachine,
			},
			{
				path: "/addRechargePackage/addRechargePackage",
				name: "addRechargePackage",
				component: addRechargePackage,
			},
			{
				path: "/userRechargeRecordTable/userRechargeRecordTable",
				name: "userRechargeRecordTable",
				component: userRechargeRecordTable,
			},
			{
				path: "/cardReplacementRecord/cardReplacementRecord",
				name: "cardReplacementRecord",
				component: cardReplacementRecord,
			},
			{
				path: "/getStatisticalReports/getStatisticalReports",
				name: "getStatisticalReports",
				component: getStatisticalReports,
			},
			{
				path: "/consumptionRecord/consumptionRecord",
				name: "consumptionRecord",
				component: consumptionRecord,
			},
			{
				path: "/cardLossRecord/cardLossRecord",
				name: "cardLossRecord",
				component: cardLossRecord,
			},
			{
				path: "/userLogoutRecord/userLogoutRecord",
				name: "userLogoutRecord",
				component: userLogoutRecord,
			},
		],
	}
]

const router = new VueRouter({
	routes
});


export default router
