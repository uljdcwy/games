export default {
	data() {
		return {
			changeMoveStatus: false,
			initElPosition: {
				x: 0,
				y: 0
			},
			initPagePosition: {
				x: 0,
				y: 0
			},
		}
	},
	mounted() {
		let moveClassList = document.getElementsByClassName('el-dialog__header');
		let that = this;
		for (let i = 0; i < moveClassList.length; i++) {
			(function(i) {
				let currentEl = moveClassList[i];
				currentEl.style.cursor = "all-scroll";
				let mousedownAddevnetListener = function(e) {
					that.changeMoveStatus = true;
					let left = parseInt(that.getStyle(currentEl.parentElement, 'left'));
					let top = parseInt(that.getStyle(currentEl.parentElement, 'top'));
					let initPageX = e.pageX;
					let initPageY = e.pageY;
					that.$set(that.initPagePosition,'x',e.pageX);
					that.$set(that.initPagePosition,'y',e.pageY);
					
					that.$set(that.initElPosition,'x',left);
					that.$set(that.initElPosition,'y',top);
					window.onmousemove = function(e) {
						if (that.changeMoveStatus) {
							that.currentElPosition({
								pageX: e.pageX,
								pageY: e.pageY,
							}, currentEl.parentElement)
						};
						return false;
					};
					window.onmouseup = function(e) {
						window.onmousemove = null;
						window.onmouseup = null;
						that.changeMoveStatus = false;
						return false;
					};
					return false;
				};
				
				currentEl.addEventListener('mousedown',mousedownAddevnetListener,false);
			})(i)
		}
	},
	methods: {
		currentElPosition(obj, el) {
			let x = ((obj.pageX - this.initPagePosition.x) + this.initElPosition.x) + "px";
			let y = ((obj.pageY - this.initPagePosition.y) + this.initElPosition.y) + "px";
			el.style.left = x;
			el.style.top = y;
		},
		getStyle(obj, attr) {
			if (obj.currentStyle) {
				return obj.currentStyle[attr]
			} else {
				return document.defaultView.getComputedStyle(obj, null)[attr]
			}
		},
	}
}
