<template>
	<el-row :gutter="20">
		<slot name="vuew"></slot>
		<slot name="dialog"></slot>
	</el-row>
</template>

<script>
</script>

<style lang="scss">
</style>