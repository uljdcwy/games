const {
	exec,
	spawn
} = require("child_process");

// All of the Node.js APIs are available in the preload process.
window.addEventListener("DOMContentLoaded", () => {
	// pm2.start({
	// 	script: './Services/index.js'
	// });
	// 生产环境
	// exec("start node.exe ./../index.js",{cwd: "./resources/Services/v14.15.4"}, function(error, stdout, stderr){
	//     if(error) {
	//         console.error('error: ' + error);
	//         return;
	//     }
	//     console.log('stdout: ' + stdout);
	//     console.log('stderr: ' + typeof stderr);
	// });

	// exec('./npm install pm2',{cwd: "./Services/v14.15.4"});
	// 开发环境
	// console.log(123456789)
	//    const execJson = exec("start node.exe ./../index.js && exit",{cwd: "./Services/v14.15.4"}, function(error, stdout, stderr){
	//     console.log(123)
	// 	if(error) {
	//         console.error('error: ' + error);
	//         return;
	//     }
	//     console.log('stdout: ' + stdout);
	//     console.log('stderr: ' + typeof stderr);
	// });
	

	// let timer = setInterval(function() {
	// 	let childPrecess = exec(`echo %PATH%`, (error, stdout, stderr) => {
	// 		console.log(error, stdout, stderr, "error, stdout, stderr", childPrecess)
	// 		if (error) {
	// 			document.title = "node 安装中 请完成node安装"
	// 			document.body.innerHTML = "<h1 class='install-h1'>node 安装中 请完成node安装</h1>"
	// 		} else {
	// 			installPm2();
	// 		}
	// 	})
	// }, 3000)


	// const execJson2 = exec("start ./node.exe ./../index.js", {
	// 	cwd: "./Services/v14.15.4"
	// }, function(error, stdout, stderr) {
	// 	if (error) {
	// 		console.error('error: ' + error);
	// 		return;
	// 	}
	// 	console.log('stdout: ' + stdout);
	// 	console.log('stderr: ' + typeof stderr);
	// });
	// console.log(execJson2,execJson2,"需要操作的句柄")

	// console.log(execJson,"execJson")
});
