'use strict'
const {
	exec,
	spawn
} = require("child_process");
const sudo = require('sudo-prompt');
import {
	app,
	protocol,
	BrowserWindow,
	Menu,
	dialog
} from 'electron'
import {
	createProtocol
} from 'vue-cli-plugin-electron-builder/lib'
import installExtension, {
	VUEJS_DEVTOOLS
} from 'electron-devtools-installer'
import path from "path"
const isDevelopment = process.env.NODE_ENV !== 'production'
import fs from "fs"

app.commandLine.appendSwitch('disable-web-security');

// Scheme must be registered before the app is ready
protocol.registerSchemesAsPrivileged([{
	scheme: 'app',
	privileges: {
		secure: true,
		standard: true
	}
}])

async function createWindow() {
	// Create the browser window.
	const win = new BrowserWindow({
		webPreferences: {
			preload: path.join(__dirname, 'preload.js'),
			// Use pluginOptions.nodeIntegration, leave this alone
			// See nklayman.github.io/vue-cli-plugin-electron-builder/guide/security.html#node-integration for more info
			nodeIntegration: process.env.ELECTRON_NODE_INTEGRATION,
			contextIsolation: !process.env.ELECTRON_NODE_INTEGRATION,
			enableRemoteModule: true,
			webSecurity: false
		},
	});



	// 判断MYSQL是否安装
	/* 	exec(`mysql -v`,(error, stdout, stderr) => {
			if(error){
			}else{
				sudo.exec(`start net start MySql`,options,(err, std, sterr) => {
					// dialog.showMessageBox({
					// 	type: 'info',
					// 	title: '查看mysql启动是否成功',
					// 	message: JSON.stringify(error) + "stdout "  + JSON.stringify(stdout) + " stderr " + JSON.stringify(stderr),
					// 	buttons: ['确定']
					// })
				})
			}
		}) */



	// win.webContents.openDevTools()
	// 判断NODE 是否安装 
	/*exec('node -v', function(err, stda, ster) {
		if (err) {
			exec(`setx "Path" "${__dirname.replace('\\app.asar','')}\\Services\\nodev13140;%Path%"`,(error, stdout, stderr) => {
				app.exit();
			})
			
			// 使用超管权限执行
					// dialog.showMessageBox({
					// 	type: 'info',
					// 	title: '提示 error',
					// 	message: JSON.stringify(error.code) + "stdout "  + JSON.stringify(stdout) + " stderr " + JSON.stringify(stderr),
					// 	buttons: ['确定']
					// })
					// 第二次执行是为了防止获取超管权限失败
					// exec(`${__dirname.replace('\\app.asar','')}\\Services\\mysql\\install_mysql.bat ${__dirname.replace('\\app.asar','')}\\Services`,(error, stdout, stderr) => {
					// 	app.quit();
					// })
					
					// app.quit();
					// 错误码为1是执行 bat文件为win10并且命令行运行成功 否则为win7 命令行执行失败以普通权限运行
					// if(error.code == 1){
					// 	app.quit();
					// }else{
					// 	exec(`${__dirname.replace('\\app.asar','')}\\Services\\mysql\\install_mysql.bat ${__dirname.replace('\\app.asar','')}\\Services`,(error, stdout, stderr) => {
					// 		return null
					// 		app.quit();
					// 	})
					// }
					
					// 在命令行调用完成时关闭窗口
					// if (!stdout) {
					// 	dialog.showMessageBox({
					// 		type: 'info',
					// 		title: '提示',
					// 		message: "运行权限不足，请使用管理员权限运行",
					// 		buttons: ['确定']
					// 	})
					// } else {
					// }
		} else {
			exec(`pm2 show index`, (error, stdout, stderr) => {
				if (stderr) {
					exec(`pm2 start index.js`, {
						cwd: "./resources/Services"
					});
				}
			});
		}
	})*/

	// win.webContents.openDevTools()

	if (process.env.WEBPACK_DEV_SERVER_URL) {
		// Load the url of the dev server if in development mode
		await win.loadURL(process.env.WEBPACK_DEV_SERVER_URL)
		if (!process.env.IS_TEST) win.webContents.openDevTools()
	} else {
		createProtocol('app');

		exec(`node -v`, (error, stdout, stderr) => {
			if (error) {
				win.loadURL('app://./loadPm2.html')
			} else {
				win.loadURL('app://./index.html')
			}
		})
	}
}


// Quit when all windows are closed.
app.on('window-all-closed', () => {
	// On macOS it is common for applications and their menu bar
	// to stay active until the user quits explicitly with Cmd + Q


	// console.log(execChild.pid)

	// process.kill(-execChild.pid)

	if (process.platform !== 'darwin') {
		app.quit()
	}
})

app.on('activate', () => {
	// On macOS it's common to re-create a window in the app when the
	// dock icon is clicked and there are no other windows open.
	if (BrowserWindow.getAllWindows().length === 0) createWindow()
})

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', async () => {

	let options = {
		name: 'Electron',
		icns: '/Applications/Electron.app/Contents/Resources/Electron.icns', // (optional)
	};
	// 查看path是否有环境变量如果没有配置
	exec(`node -v`, (error, stdout, stderr) => {
		if (error) {
			createWindow();
			Menu.setApplicationMenu(null);
			exec(`setx "Path" "${__dirname.replace('\\app.asar','')}\\Services\\nodev13140;${__dirname.replace('\\app.asar','')}\\Services\\mysql\\bin;%Path%"`,
				(error, stdout, stderr) => {

				})
			sudo.exec(
				`start ${__dirname.replace('\\app.asar','')}\\Services\\mysql\\install_mysql.bat ${__dirname.replace('\\app.asar','')}\\Services`,
				options, (error, stdout, stderr) => {
					app.exit();
				})
		} else {
			exec(`pm2 show index`, (error, stdout, stderr) => {
				if (stderr) {
					exec(`pm2 start index.js`, {
						cwd: "./resources/Services"
					}, (error, stdout, stderr) => {
						createWindow();
						Menu.setApplicationMenu(null);
					});
				} else {
					createWindow();
					Menu.setApplicationMenu(null);
				}
			});
			// sudo.exec(`net start MySql`,options)
		}
	})

	/*  if (isDevelopment && !process.env.IS_TEST) {
	    // Install Vue Devtools
	    try {
	      await installExtension(VUEJS_DEVTOOLS)
	    } catch (e) {
	      console.error('Vue Devtools failed to install:', e.toString())
	    }
	  } */
	// nodeCmd.run('node ./resources/Services/index.js')
})

// Exit cleanly on request from parent process in development mode.
if (isDevelopment) {
	if (process.platform === 'win32') {
		process.on('message', (data) => {
			if (data === 'graceful-exit') {
				app.quit()
			}
		})
	} else {
		process.on('SIGTERM', () => {
			app.quit()
		})
	}
}
