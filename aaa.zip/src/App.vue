<template>
	<router-view></router-view>
</template>
<script type="text/javascript">
	export default {
		name: "app",
		data() {
			return {}
		},
		mounted() {
		}
	}
</script>
<style lang="scss">
	html,body{
		min-height: 100%;
	}
</style>
