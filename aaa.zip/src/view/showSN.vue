<template>
	<div>该电脑暂无授权，请联系客服:{{SNTip}}</div>
</template>

<script>
	import { mapMutations, mapState } from 'vuex'
	import {
		sysCheckAuth,
		sysGetSN
	} from './../http/http.js'
	export default {
		name: "showSN",
		data(){
			return {
				SNTip: ""
			}
		},
		mounted() {
			let that = this;
			// that.setCurrentComponents('login')
			// sysCheckAuth().then(function(res){
			// 	if(res.data.code < 0){
			// 		sysGetSN().then(function(res){
			// 			console.log(res,"查看返回数据");
			// 			that.SNTip = res.data.SN
			// 			res.loadingStatus?.close();
			// 		})
			// 	}else{
			// 		that.setCurrentComponents('login')
			// 	}
			// })
			setTimeout(() => {
				this.setCurrentComponents('login')
			},6000)
			
		},
		methods: {
			...mapMutations(['setCurrentComponents'])
		}
	}
</script>

<style>
</style>