<template>
	<el-row class="card-reading-information">
		<el-col :span="8">
			<el-row>
				<span>人员编号：</span><el-input size="small" placeholder="请输入人员编号" v-model="personNumber">
				</el-input>
			</el-row>
			<el-row>
				<span>人员姓名：</span><el-input size="small" placeholder="请输入人员姓名" v-model="personName">
				</el-input>
			</el-row>
			<el-row>
				<span>部门名称：</span><el-input size="small" placeholder="请输入部门名称" v-model="deptName">
				</el-input>
			</el-row>
			<el-row>
				<span>职务名称：</span><el-input size="small" placeholder="请输入职务名称" v-model="jobName">
				</el-input>
			</el-row>
			<el-row>
				<span>身份证：</span><el-input size="small" placeholder="请输入身份证" v-model="ID">
				</el-input>
			</el-row>
			<el-row>
				<span>手机号码：</span><el-input size="small" placeholder="请输入手机号码" v-model="phone">
				</el-input>
			</el-row>
		</el-col>
		<el-col :span="8">
			<el-row>
				<span>卡 号：</span><el-input size="small" placeholder="请输入卡 号" v-model="cardNumber">
				</el-input>
			</el-row>
			<el-row>
				<span>现金余额：</span><el-input size="small" placeholder="请输入现金余额" v-model="cashBalance">
				</el-input>
			</el-row>
			<el-row>
				<span>补贴余额：</span><el-input size="small" placeholder="请输入补贴余额" v-model="subsidyBalance">
				</el-input>
			</el-row>
			<el-row>
				<span>卡片押金：</span><el-input size="small" placeholder="请输入卡片押金" v-model="cardEmbossing">
				</el-input>
			</el-row>
			<el-row>
				<span>人员级别：</span><el-input size="small" placeholder="请输入人员级别" v-model="personLevels">
				</el-input>
			</el-row>
		</el-col>
		<el-col :span="8">
			<el-row>
				<span>民族信息：</span><el-input size="small" v-model="ethnicInformation">
				</el-input>
			</el-row>
			<el-row>
				<span>省/直辖市：</span><el-input size="small" v-model="municipality">
				</el-input>
			</el-row>
			<el-row>
				<span>城市：</span><el-input size="small" v-model="city">
				</el-input>
			</el-row>
			<el-row>
				<span>区县：</span><el-input size="small" v-model="districtsCounties">
				</el-input>
			</el-row>
		</el-col>
	</el-row>
</template>

<script>
	export default {
		name: 'cardReadingInformation',
		data() {
			return {
				personNumber: '',
				personName: '',
				deptName: '',
				jobName: '',
				ID: '',
				phone: '',
				cardNumber: '',
				cashBalance: '',
				subsidyBalance: '',
				cardEmbossing: '',
				personLevels: '',
				ethnicInformation: '',
				municipality: '',
				city: '',
				districtsCounties: '',
			}
		}
	}
</script>

<style>
</style>
