<template>
	<el-container>
		<el-main class="table-show">
			<data-add-del-mod-find :tableHeight="tableMinHeight" @resetDialog="resetDialog" :tableDataObj="tableDataObj"
				@addData="opearAdd" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus"
				:fromDataObj="fromDataObj" @getList="getList" @showDialog="showDialog" @saveModifyBtn="saveModifyBtn">
				<template slot="opera" slot-scope="porps">
					<el-button size="small" type="primary" @click="modifyData(porps)">修改</el-button>
					<el-button size="small" type="danger" @click="deleteData(porps)">删除</el-button>
					<el-button size="small" type="danger" @click="clearPersonInfo(porps)">清除消费机信息</el-button>
				</template>
				<template slot="is_online" slot-scope="{ opera }">
					{{ opera.is_online == 1 ? '在线' : '不在线' }}
				</template>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		DeviceDelete,
		DeviceAdd,
		DeviceGetList,
		DeviceUpdate,
		DeviceReDownLoadFace,
		AreaGetList
	} from "./../http/http.js"

	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				currentPage: 1,
				pageSize: 15,
				dialogStatus: 1,
				areaList: [],
				searchName: '',
				fromDataObj: {
					searchPlaceholder: "请输入消费机名称",
					opera: false,
					title: "消费机管理",
					formList: {
						device_name: {
							type: 'text',
							label: "消费机名称",
							value: "",
							require: true,
							searchAdv: true,
							validator: function(label, item, callback) {
								if (item.value) {
									callback();
								} else {
									callback('请输入消费机名称');
								}
							}
						},
						model: {
							type: 'select',
							label: "消费机类型",
							value: "",
							searchAdv: false,
							require: true,
							children: [{
								label: 'hpt',
								value: 'hpt',
							}],
							validator: function(label, item, callback) {
								if (item.value) {
									callback();
								} else {
									callback('请选择消费机类型');
								}
							}
						},
						area_id: {
							type: 'select',
							label: "消费机区域",
							value: "",
							searchAdv: true,
							require: false,
							children: [],
						},
					},
					labelWidth: '120px'
				},
				tableDataObj: {
					selection: false,
					index: false,
					opera: true,
					minWidth: '280px',
					columnList: [{
						prop: 'id',
						width: "100px",
						label: '设备号',
						slot: false,
						sortable: true,
					},{
						prop: 'device_name',
						width: "160px",
						label: '消费机名称',
						slot: false,
						sortable: true,
					}, {
						prop: 'area',
						width: '160px',
						label: '消费机区域',
						slot: false,
						sortable: true,
					}, {
						prop: 'is_online',
						width: "150px",
						label: '消费机在线状态',
						slot: true,
						sortable: true,
					},
					{
						prop: 'model',
						width: "160px",
						label: '消费机类型',
						slot: false,
						sortable: true,
					}],
					tableData: [{
						device_name: '',
						area_id: '',
						area: '',
						model: ''
					}]
				},
				currentModify: '',
				area_id: ''
			}
		},
		created() {
			let that = this;
			AreaGetList().then(function(res) {
				let data = res.data.data;
				for (let i = 0; i < data.length; i++) {
					data[i].label = data[i].area_name;
					data[i].value = data[i].id;
				}
				that.fromDataObj.formList.area_id.children = data;
				that.getList();
			})
		},
		methods: {
			clearPersonInfo(data) {
				let that = this;
				that.$confirm('此操作将永久清除消费机信息, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if (actions == 'confirm') {
						DeviceReDownLoadFace({
							"id": data.opera.id,
						}).then(function(res) {
							if (res.data.code == 1) {
								console.log(res, "res")
								that.$message.success('清除消费机信息成功');
								that.getList();
							}
						})
					}
				})
			},
			resetDialog() {
				let data = this.fromDataObj.formList;
				for (let key in data) {
					this.fromDataObj.formList[key].value = '';
				}
			},
			modifyData(data) {
				this.dialogVisible = true;
				this.dialogStatus = 3;
				this.fromDataObj.formList.device_name.value = data.opera.device_name;
				this.fromDataObj.formList.area_id.value = data.opera.area_id;
				this.fromDataObj.formList.model.value = data.opera.model;
				this.currentModify = data;
				this.$children[0]?.$children[0]?.$children[0]?.$refs?.form?.clearValidate();
				// console.log(this.$children[0].$children[0].$children[0],"this.$children[0].$children[0].$children[0]")
			},
			deleteData(data) {
				let that = this;
				that.$confirm('此操作将永久删除该消费机, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if (actions == 'confirm') {
						DeviceDelete({
							"id": data.opera.id
						}).then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('删除消费机成功');
								that.getList();
							}
						})
					}
				})
			},
			saveModifyBtn(data) {
				let that = this;
				console.log(this.currentModify.opera.id, "this.currentModify.id")
				DeviceUpdate({
					"id": this.currentModify.opera.id,
					"device_name": data.device_name.value,
					"model": data.model.value,
					"area_id": data.area_id.value
				}).then(function(res) {
					if (res.data.code == 1) {
						that.$message.success('修改消费机成功');
						that.getList();
					}
				})
			},
			opearAdd(data) {
				let that = this;
				DeviceAdd({
					"device_name": data.device_name.value,
					"model": data.model.value,
					"area_id": data.area_id.value
				}).then(function(res) {
					if (res.data.code == 1) {
						that.$message.success('添加消费机成功');
						that.getList();
					}
				})
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if (obj.advSearch) {
					this.area_id = this.fromDataObj.formList.area_id.value;
					this.searchName = obj.device_name.value;
				} else if (obj.searchName === '' || obj.searchName) {
					this.resetDialog();
					this.area_id = '';
					this.searchName = obj.searchName
				}

				that.currentPage = obj.currentPage || that.currentPage;
				that.pageSize = obj.pageSize || that.pageSize;
				if(obj.SortField == 'area') obj.SortField = 'area_id';
				
				DeviceGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "device_name",
					"SortOrder": obj.SortOrder || "DESC",
					'device_name': this.searchName,
					'area_id': this.area_id,
				}).then(function(res) {
					let data = res.data.data;
					let areaList = that.fromDataObj.formList.area_id.children;
					for (let i = 0; i < data.length; i++) {
						for (let j = 0; j < areaList.length; j++) {
							if (data[i].area_id == areaList[j].id) {
								data[i].area = areaList[j].area_name;
							}
						}
					}
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if (index !== 3) {
					this.resetDialog();
				};
				if (index === '') {
					this.dialogVisible = false;
				} else {
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
			}
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
