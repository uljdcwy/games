<template>
	<el-container>
		<el-main>
			<data-add-del-mod-find :tableHeight="tableMinHeight" :addData="false" @resetDialog="resetDialog"
				@selectionChange="selectionChange" :tableDataObj="tableDataObj" :dialogVisible='dialogVisible'
				:dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList" @showDialog="showDialog">
				<div slot="manyOpera" style="display: inline-block;">
					<el-button type="danger" size="small" @click="clearSelectedFaceTask" style="margin-right: 10px;">
						清除选中人脸同步任务</el-button>
					<el-button type="danger" size="small" style="margin-left: 0;margin-right: 10px;"
						@click="clearAllFaceTask">清除所有人脸任务</el-button>
				</div>
				<div slot="data" slot-scope="row">
					<el-button size="small" :disabled="!JSON.parse(row.opera.data).faceDataUrl" @click="lookDetails(row)">查看</el-button>
				</div>
			</data-add-del-mod-find>
		</el-main>
		<el-dialog title="人脸任务详情" :visible.sync="personTaskDetails" width="30%" :show-close='false'>
			<div slot="title">
				用户管理
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="personTaskDetails = false"></i>
			</div>
			<div class="title">{{descriptions.accountName}}</div>
			<div class="title">
				<el-image :src="$http.options.root + '/hpt/v2/' + descriptions.faceDataUrl"></el-image>
			</div>
		</el-dialog>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		TaskFaceSyncGetList,
		TaskFaceSyncDeleteAll,
		TaskFaceSyncDelete
	} from "./../http/http.js"

	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				personTaskDetails: false,
				dialogVisible: false,
				descriptions: {},
				total: 0,
				pageSize: 15,
				currentPage: 1,
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "人脸任务管理",
					searchPlaceholder: "请输入指令类型",
					formList: {
						type: {
							type: 'text',
							label: "指令类型",
							value: "",
							require: false,
							searchAdv: true
						},
						account_id: {
							type: 'text',
							label: "用户编号",
							value: "",
							require: false,
							searchAdv: true
						},
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: false,
					selection: true,
					index: false,
					columnList: [{
						prop: 'type',
						width: "120px",
						label: '指令类型',
						slot: false,
						sortable: true,
					}, {
						prop: 'device_id',
						width: "120px",
						label: '设备ID',
						slot: false,
						sortable: true,
					}, {
						prop: 'account_id',
						width: "120px",
						label: '用户编号',
						slot: false,
						sortable: true,
					}, {
						prop: 'data',
						width: "120px",
						label: '查看详情',
						slot: true,
						sortable: true,
					}, {
						prop: 'create_time',
						width: "120px",
						label: '创建时间',
						slot: false,
						sortable: true,
					}],
					tableData: []
				},
				currentID: '',
				clearTaskList: []
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
			TaskFaceSyncGetList()
		},
		methods: {
			lookDetails(data) {
				this.descriptions = JSON.parse(data.opera.data);
				this.personTaskDetails = true;
				console.log(this.descriptions, "this.descriptions")
			},
			selectionChange(e) {
				let that = this;
				this.clearTaskList = []
				console.log(e, "查看先中数据列表");
				e.map(function(data) {
					that.clearTaskList.push(data.id)
				})
			},
			clearSelectedFaceTask() {
				let that = this;
				if (!this.clearTaskList[0]) {
					this.$message.warning("请选择清除人脸任务列表")
					return null
				}

				that.$confirm('此操作将永久清除选中人脸任务, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if (actions == 'confirm') {
						TaskFaceSyncDelete({
							"ids": that.clearTaskList
						}).then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('清除成功');
								that.getList();
							}
						})
					}
				})
			},
			clearAllFaceTask() {
				let that = this;
				that.$confirm('此操作将永久清除人脸任务, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if (actions == 'confirm') {
						TaskFaceSyncDeleteAll().then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('清除成功');
								that.getList();
							}
						})
					}
				})
			},
			resetDialog() {
				let data = this.fromDataObj.formList;
				for (let key in data) {
					this.fromDataObj.formList[key].value = '';
				}
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if (obj.advSearch) {
					this.searchName = obj.type.value;
				} else if (obj.searchName === '' || obj.searchName) {
					this.resetDialog();
					this.searchName = obj.searchName;
				}

				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize

				TaskFaceSyncGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "type",
					"SortOrder": obj.SortOrder || "DESC",
					'type': this.searchName || '',
					"account_id": this.fromDataObj.formList.account_id?.value || '',
				}).then(function(res) {
					let data = res.data.data;

					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if (index === '') {
					this.dialogVisible = false;
				} else {
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
	.title{
		text-align: center;
	}
</style>
