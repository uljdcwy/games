<template>
	<el-container>
		<el-main class="table-show">
			<data-add-del-mod-find :tableHeight="tableMinHeight" @resetDialog="resetDialog" :tableDataObj="tableDataObj" @addData="opearAdd" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList"
				@showDialog="showDialog" @saveModifyBtn="saveModifyBtn">
				<div slot="opera" slot-scope="porps">
					<el-button size="small" type="primary" @click="modifyData(porps)">修改</el-button>
					<el-button size="small" type="danger" @click="deleteData(porps)">删除</el-button>
				</div>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList"></main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		AreaAdd,
		AreaGetList,
		AreaRemove,
		AreaUpdate
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				currentPage: 1,
				pageSize: 15,
				dialogStatus: 1,
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "区域信息管理",
					searchPlaceholder: "请输入区域名称",
					formList: {
						area_name: {
							type: 'text',
							label: "区域名称",
							value: "",
							require: true,
							searchAdv: true,
							validator: function(label,item,callback){
								if(item.value){
									callback();
								}else{
									callback('请输入区域名称');
								}
							}
						},
						area_code: {
							type: 'text',
							label: "区域代码",
							value: "",
							require: false,
							searchAdv: true
						},
						// father_id: {
						// 	type: 'select',
						// 	label: "上级区域",
						// 	value: 1,
						// 	require: false,
						// 	children: [
						// 		{
						// 			label: "123",
						// 			value: 1
						// 		},
						// 		{
						// 			label: "sfs",
						// 			value: 2
						// 		},
						// 		{
						// 			label: "zheng",
						// 			value: 3
						// 		},								
						// 	],
						// 	searchAdv: false
						// },
						// level: {
						// 	type: 'text',
						// 	label: "区域级别",
						// 	value: 1,
						// 	require: false,
						// 	searchAdv: false
						// }
					},
					labelWidth: '120px'
				},
				tableDataObj: {
					selection: false,
					index: false,
					opera: true,
					minWidth: "150px",
					columnList: [{
						prop: 'area_name',
						width: "160px",
						label: '区域名称',
						slot: false,
						sortable: true,
					},{
						prop: 'area_code',
						width: "80px",
						label: '区域代码',
						slot: false,
						sortable: true,
					},
					// {
					// 	prop: 'father_id',
					// 	width: false,
					// 	label: '上级区域',
					// 	slot: false,
					// 	sortable: false,
					// },
					// {
					// 	prop: 'level',
					// 	width: false,
					// 	label: '区域级别',
					// 	slot: false,
					// 	sortable: false,
					// }
					],
					tableData: [],
					area_code: ''
				},
				currentModify: ''
			}
		},
		mounted() {
			this.getList();
		},
		methods: {
			deleteData(data){
				let that = this;
				that.$confirm('此操作将永久删除该区域, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if(actions == 'confirm'){
						AreaRemove({
							'id': data.opera.id
						}).then(function(res){
							if(res.data.code == 1){
								that.getList();
								that.$message.success('删除区域成功');
							}
						})
					}
				})
			},
			opearAdd(data){
				let that = this;
				AreaAdd({
					"area_name": data.area_name.value,
					"level": 0,
					"area_code": data.area_code.value,
					// "father_id": Number(data.father_id.value)
				}).then(function(res){
					if(res.data.code == 1){
						that.getList();
						that.$message.success('新增区域成功');
					}
				})
			},
			resetDialog(){
				let data = this.fromDataObj.formList;
				for(let key in data){
					this.fromDataObj.formList[key].value = '';
				}
			},
			modifyData(data){
				this.dialogStatus = 3;
				this.dialogVisible = true;
				this.fromDataObj.formList.area_name.value = data.opera.area_name;
				this.fromDataObj.formList.area_code.value = data.opera.area_code;
				// this.fromDataObj.formList.father_id.value = data.opera.father_id;
				// this.fromDataObj.formList.level.value = data.opera.level;
				this.currentModify = data;
				this.$children[0]?.$children[0]?.$children[0]?.$refs?.form?.clearValidate();
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				
				// 点击了高级搜索
				if(obj.advSearch){
					this.area_code = this.fromDataObj.formList.area_code.value;
					this.searchName = obj.area_name.value;
				}else if(obj.searchName === '' || obj.searchName){
					this.resetDialog();
					this.area_code = '';
					this.searchName = obj.searchName;
				}
				
				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize
				
				AreaGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "area_name",
					"SortOrder": obj.SortOrder || "DESC",
					'area_name': this.searchName,
					'area_code': this.area_code
				}).then(function(res){
					let data = res.data.data;
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					console.log(res.data.count,"res.data.count")
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if(index !== 3){
					this.resetDialog();
				};
				if(index === ''){
					this.dialogVisible = false;
				}else{
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
			},
			saveModifyBtn(data){
				let that = this;
				console.log(this.currentModify.opera.id,"currentModify");
				AreaUpdate({
					"id": this.currentModify.opera.id,
					"area_name": data.area_name.value,
					"level": 0,
					"area_code": data.area_code.value,
					// "father_id": data.father_id.value
				}).then(function(res){
					if(res.data.code == 1){
						that.getList();
						that.$message.success('修改区域成功');
					}
				})
			}
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
