<template>
	<el-container :class="setOpacity">
		<el-main class="table-show role-management">
			<data-add-del-mod-find :tableHeight="tableMinHeight" @resetDialog="resetDialog" :tableDataObj="tableDataObj" @addData="RoleAdd" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList"
				@showDialog="showDialog" @saveModifyBtn="saveModifyBtn">
				<div slot="opera" slot-scope="porps">
					<el-button size="small" type="primary" @click="modifyData(porps)">修改</el-button>
					<el-button size="small" type="danger" @click="deleteData(porps)">删除</el-button>
				</div>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList"></main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		RoleAdd,
		RoleGetList,
		RoleRemove,
		RoleUpdate
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				pageSize: 15,
				currentPage: 1,
				searchName: '',
				setOpacity: 'setOpacity',
				fromDataObj: {
					opera: false,
					title: "角色管理",
					searchPlaceholder: "请输入角色名称",
					formList: {
						permissionGroupName: {
							type: 'text',
							label: "角色名称",
							value: "",
							require: true,
							searchAdv: true,
							validator: function(label,item,callback){
								if(item.value){
									callback();
								}else{
									callback('请输入角色名称');
								}
							}
						},
						permissionList: {
							type: 'checkbox',
							label: "请选择角色",
							value: [],
							children: [
								{
									label: '角色管理',
									disabled: false,
									value: false
								},
								{
									label: '帐号管理',
									disabled: false,
									value: false
								},
								{
									label: '区域信息管理',
									disabled: false,
									value: false
								},
								{
									label: '消费机',
									disabled: true,
									value: true
								},
								{
									label: '人事信息管理',
									disabled: false,
									value: false
								},
								{
									label: '报表',
									disabled: false,
									value: false
								},
								{
									label: '人脸同步任务管理',
									disabled: false,
									value: false
								},
							],
							require: false,
							searchAdv: false
						},
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: true,
					selection: false,
					index: false,
					minWidth: '150px',
					columnList: [{
						prop: 'role_name',
						width: "160px",
						label: '角色名称',
						slot: false,
						sortable: true,
					}, 
					// {
					// 	prop: 'role_value',
					// 	width: false,
					// 	label: '权限值',
					// 	slot: false,
					// 	sortable: false
					// }, 
					{
						prop: 'update_time',
						width: "160px",
						label: '更新时间',
						slot: false,
						sortable: true
					}],
					tableData: []
				},
				currentID: ''
			}
		},
		created() {
			this.dialogVisible = true;
			setTimeout(() => {
				this.dialogVisible = false;
				setTimeout(() => {
					this.setOpacity = '';
				},1000)
			},1)
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
			
		},
		methods: {
			resetDialog(cb){
				let data = this.fromDataObj.formList;
				for(let key in data){
					if(key == 'permissionList'){
						this.fromDataObj.formList[key].value = ['消费机'];
					}else{
						this.fromDataObj.formList[key].value = '';
					}
				}
				cb && cb();
			},
			modifyData(porps){
				// this.$children[0]?.$children[0]?.$children[0]?.$refs?.form?.clearValidate();
				this.dialogVisible = true;
				this.dialogStatus = 3;
				this.currentID = porps.opera.id;
				this.fromDataObj.formList.permissionGroupName.value = porps.opera.role_name;
				console.log(this.fromDataObj.formList.permissionList.value,"查看当前属性是否为晌应属性")
				this.fromDataObj.formList.permissionList.value = Array.isArray(JSON.parse(porps.opera.role_value)) ? JSON.parse(porps.opera.role_value) : ['消费机'];
			},
			deleteData(porps){
				let that = this;
				that.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if(actions == 'confirm'){
						RoleRemove({
							"id": porps.opera.id
						}).then(function(res){
							if(res.data.code == 1){
								that.$message.success('删除角色成功');
								that.getList();
							}
						})
					}
				})
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if(obj.advSearch){
					obj.searchName = obj.permissionGroupName.value;
				}
				
				if(obj.searchName === ''){
					this.searchName = '';
				}else{
					this.searchName = obj.searchName || this.searchName;
				}
				
				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize
				
				RoleGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "role_name",
					"SortOrder": obj.SortOrder || "DESC",
					'role_name': this.searchName || ''
				}).then(function(res){
					that.tableDataObj.tableData = res.data.data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			RoleAdd(data){
				let that = this;
				RoleAdd({
					role_name: data.permissionGroupName.value,
					role_value: JSON.stringify(data.permissionList.value)
				}).then(function(res){
					if(res.data.code == 1){
						that.$message.success('添加角色成功');
						that.getList();
					}
				})
			},
			showDialog(index){
				console.log(index,this.fromDataObj.formList.permissionList)
				if(index !== 3){
					this.resetDialog();
				};
				if(index === ''){
					this.dialogVisible = false;
				}else{
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
			saveModifyBtn(data){
				let that = this;
				RoleUpdate({
					id: this.currentID,
					role_name: data.permissionGroupName.value,
					role_value: JSON.stringify(data.permissionList.value)
				}).then(function(res){
					if(res.data.code == 1){
						that.$message.success('修改角色成功');
						that.getList();
					}
				})
			}
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
