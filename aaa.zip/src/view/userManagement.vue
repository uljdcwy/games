<template>
	<el-container>
		<el-main class="table-show">
			<data-add-del-mod-find :tableHeight="tableMinHeight" @resetDialog="resetDialog" :tableDataObj="tableDataObj" @addData="opearAdd" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList"
				@showDialog="showDialog" @saveModifyBtn="saveModifyBtn">
				<div slot="opera" slot-scope="porps">
					<el-button size="small" type="primary" @click="modifyData(porps)">修改</el-button>
					<el-button size="small" type="danger" @click="deleteData(porps)">删除</el-button>
				</div>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList"></main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		RoleGetList,
		OperAdd,
		OperGetList,
		OperUpdate,
		OperRemove
	} from "./../http/http.js"
	
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				currentPage: 1,
				pageSize: 15,
				dialogStatus: 1,
				searchName: '',
				fromDataObj: {
					searchPlaceholder: "请输入帐号名称",
					opera: false,
					title: "帐号管理",
					formList: {
						oper_name: {
							type: 'text',
							label: "操作员名称",
							value: "",
							searchAdv: true,
							require: true,
							validator: function(label,item,callback){
								if(item.value || !item.require){
									callback();
								}else{
									callback('请输入操作员名称');
								}
							}
						},
						account: {
							type: 'text',
							label: "帐号",
							value: "",
							searchAdv: true,
							require: true,
							validator: function(label,item,callback){
								if(item.value || !item.require){
									callback();
								}else{
									callback('请输入帐号');
								}
							}
						},
						password: {
							type: 'password',
							label: "密码",
							value: "",
							require: false
						},
						role_id: {
							type: 'select',
							label: "角色",
							value: "",
							children: [],
							require: true,
							validator: function(label,item,callback){
								if(item.value){
									callback();
								}else{
									callback('请选择角色');
								}
							}
						},
						phone: {
							type: 'text',
							label: "手机号",
							value: "",
							require: false,
							searchAdv: true,
							msg: "请输入手机号"
						},
						remark: {
							type: 'textarea',
							label: "备注",
							value: "",
							require: false,
							msg: "请输入备注"
						}
					},
					labelWidth: '120px'
				},
				tableDataObj: {
					selection: false,
					index: false,
					opera: true,
					minWidth: '150px',
					columnList: [{
						prop: 'account',
						width: '160px',
						label: '帐号',
						slot: false,
						sortable: true,
					},{
						prop: 'oper_name',
						width: '160px',
						label: '操作员名称',
						slot: false,
						sortable: true,
					},{
						prop: 'role_name',
						width: '160px',
						label: '角色',
						slot: false,
						sortable: true,
					},{
						prop: 'phone',
						width: '160px',
						label: '手机号',
						slot: false,
						sortable: true,
					},{
						prop: 'remark',
						width: '160px',
						label: '备注',
						slot: false,
						sortable: true,
					}],
					tableData: [{
						account: '',
						oper_name: '',
						role_name: "",
						phone: '',
						remark: ""
					}]
				},
				accountInfo: '',
				oper_name: '',
				phone: ''
			}
		},
		mounted(){
			let that = this;
			this.getRoleGroup(function(){
				that.getList();
			});
		},
		methods: {
			resetDialog(){
				let data = this.fromDataObj.formList;
				for(let key in data){
					this.fromDataObj.formList[key].value = '';
				}
			},
			modifyData(data){
				this.dialogVisible = true;
				this.dialogStatus = 3;
				this.fromDataObj.formList.account.value = data.opera.account;
				this.fromDataObj.formList.oper_name.value = data.opera.oper_name;
				this.fromDataObj.formList.role_id.value = data.opera.role_id;
				this.fromDataObj.formList.phone.value = data.opera.phone;
				this.fromDataObj.formList.remark.value = data.opera.remark;
				this.accountInfo = data;
				this.$children[0]?.$children[0]?.$children[0]?.$refs?.form?.clearValidate();
			},
			deleteData(data){
				let that = this;
				that.$confirm('此操作将永久删除该帐号, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then((actions) => {
					if(actions == 'confirm'){
						OperRemove({
							"account": data.opera.account
						}).then(function(res){
							if(res.data.code == 1){
								that.$message.success('删除帐号成功');
								that.getList();
							}
						})
					}
				})
			},
			// 获取权限组
			getRoleGroup(cb){
				let that = this;
				RoleGetList().then(function(res){
					let arr = [];
					let data = res.data.data;
					for(let i = 0; i < data.length; i++){
						arr.push({
							label: data[i].role_name,
							value: data[i].id
						})
					};
					
					if(!arr[0]){
						that.$message.error("请添加角色后再加帐号");
						that.$nextTick(function(){
							document.getElementsByClassName('is-active')[1].classList.remove('is-active');
						})
						that.$router.push('../index/index')
						return null;
					}
					
					that.fromDataObj.formList.role_id.children = arr;
					cb && cb();
				})
			},
			saveModifyBtn(data){
				let that = this;
				OperUpdate({
					"account": data.account.value,
					"password": data.password.value,
					"oper_name": data.oper_name.value,
					"role_id": data.role_id.value,
					"phone": data.phone.value,
					"remark": data.remark.value
				}).then(function(res){
					if(res.data.code == 1){
						that.$message.success('修改帐号成功');
						that.getList();
					}
				})
			},
			opearAdd(data){
				let that = this;
				OperAdd({
					"account": data.account.value,
					"password": data.password.value,
					"oper_name": data.oper_name.value,
					"role_id": data.role_id.value,
					"phone": data.phone.value,
					"remark": data.remark.value
				}).then(function(res){
					if(res.data.code == 1){
						that.$message.success('添加帐号成功');
						that.getList();
					}
				})
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if(obj.advSearch){
					obj.searchName = obj.account.value;
					this.oper_name = obj.advSearch && this.fromDataObj.formList.oper_name.value;
					this.phone = obj.advSearch && this.fromDataObj.formList.phone.value;
					this.searchName = obj.account.value
				}else if(obj.searchName === '' || obj.searchName){
					this.resetDialog();
					this.oper_name = '';
					this.phone = '';
					this.searchName = obj.searchName
				}
				
				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize
				
				OperGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "account",
					"SortOrder": obj.SortOrder || "DESC",
					'account': this.searchName,
					'oper_name': this.oper_name,
					'phone': this.phone
				}).then(function(res){
					let data = res.data.data;
					let roleGroupList = that.fromDataObj.formList.role_id.children;
					for(let i = 0; i < data.length; i++){
						for(let j = 0 ; j < roleGroupList.length ; j++){
							if(data[i].role_id == roleGroupList[j].value){
								data[i].role_name = roleGroupList[j].label || '';
							}
						}
					};
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if(index !== 3){
					this.resetDialog();
				};
				if(index === ''){
					this.dialogVisible = false;
				}else{
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
			}
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
