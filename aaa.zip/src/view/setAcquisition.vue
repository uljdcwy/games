<template>
	<el-container>
		<el-main>
			<form-update-find labelWidth='140px' :formUpdateFind="formUpdateFind">
				<el-button size="small" type="primary" slot="clearRecord">清除无效记录</el-button>
			</form-update-find>
		</el-main>
	</el-container>
</template>

<script>
	import formUpdateFind from "./commonTemplates/formUpdateFind.vue"
	export default {
		components: {
			formUpdateFind
		},
		data() {
			return {
				formUpdateFind: {
					serialNumber: {
						type: 'select',
						label: "发卡器连接串口号",
						value: '',
						require: false,
						children: [{
								label: "COM4",
								value: "1"
							}
						],
					},
					autoLogin: {
						type: 'checkbox',
						label: "自动登录系统",
						value: [],
						require: false,
						children: [{
								label: "",
								value: "1"
							},
						],
					},
					resetLoginPassword: {
						type: 'button',
						label: "",
						value: '',
						require: false,
						content: '重置登录密码'
					},
					collectionEquipment: {
						type: 'select',
						label: "人脸采集设备",
						value: '',
						require: false,
						slotAfter: true,
						slotAfterName: 'clearRecord',
						children: [{
								label: "7（182.168.12）",
								value: "1"
							}
						],
					},
				},
			}
		},
		methods: {
		},
	}
</script>

<style>
</style>
