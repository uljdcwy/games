<template>
	<component :logo="logo" class="component-box" :asideList="asideList" :is="currentComponents" title="智能实时消费系统"
		@changeLoginStatus="changeLoginStatus" @loginOut="loginOut" />
</template>

<script>
	import {
		OperLogin,
		RoleGetList
	} from './../http/http.js'
	import { mapMutations, mapState } from 'vuex'
	import login from "./commonTemplates/loginPreSetSql.vue";
	import loginSuccess from "./commonTemplates/loginSuccessRole.vue";
	import showSN from "./showSN.vue";
	export default {
		name: 'index',
		components: {
			login,
			loginSuccess,
			showSN
		},
		data() {
			return {
				loginStaus: 'false',
				asideList: [{
						label: "区域信息管理",
						path: "/regionalInformationManagement/regionalInformationManagement",
						icon: 'el-icon-place'
					},{
						label: "角色管理",
						path: "/index/index",
						icon: 'el-icon-view'
					},{
						label: "帐号管理",
						path: "/userManagement/userManagement",
						icon: 'el-icon-user'
					},
					{
						label: "消费机",
						path: "/consumerMachine/consumerMachine",
						icon: 'el-icon-c-scale-to-original'
					}, 
					// {
					// 	label: "系统参数设置",
					// 	children: [
					// 		{
					// 			label: "基本设置",
					// 			path: "/basicSettings/basicSettings",
					// 		},						
					// 		{
					// 			label: "全局设置",
					// 			path: "/globalSettings/globalSettings",
					// 		}
					// 	],
					// }, 
					
					// {
					// 	label: "管理卡",
					// 	path: "/managementCard/managementCard",
					// },
					{
						label: "人事信息管理",
						path: "/personInfoManage/personInfoManage",
						icon: 'el-icon-tickets'
					},
					{
						label: "人脸同步任务管理",
						path: "/personFaceTask/personFaceTask",
						icon: 'el-icon-camera'
					},
					// {
					// 	label: "优惠套餐",
					// 	path: "/addRechargePackage/addRechargePackage",
					// }, 
					// { 
					// 	label: "读卡信息",
					// 	path: "/cardReadingInformation/cardReadingInformation",
					// },{
					// 	label: "人事资料导入",
					// 	path: "/ImportPersonnelData/ImportPersonnelData",
					// },{
					// 	label: "采集设备管理",
					// 	children: [
					// 		{
					// 			label: "设置采集设备",
					// 			path: "/setAcquisition/setAcquisition",
					// 		},						
					// 		{
					// 			label: "采集设备操作日志",
					// 			path: "/operationLogs/operationLogs",
					// 		}
					// 	],
					// },
					{
						label: "报表",
						icon: 'el-icon-document-copy',
						children: [{
								label: "用户注销记录",
								path: "/userLogoutRecord/userLogoutRecord",
							},
							{
								label: "卡片挂失记录",
								path: "/cardLossRecord/cardLossRecord",
							},
							{
								label: "消费记录表",
								path: "/consumptionRecord/consumptionRecord",
							},
							{
								label: "获取日统计报表",
								path: "/getStatisticalReports/getStatisticalReports",
							},
							{
								label: "换卡记录",
								path: "/cardReplacementRecord/cardReplacementRecord",
							},
							{
								label: "用户充值记录表",
								path: "/userRechargeRecordTable/userRechargeRecordTable",
							}
						],
					},
				],
				logo: ''
			}
		},
		mounted() {
			this.setCurrentComponents("showSN");
			// this.$cookies.set('currentComponents','',60*60*24);
			// 判断是否登录如果登录并且token在有效期内则自动进入首页或者当前路由页
			// if (this.currentComponents == 'loginSuccess') {
			// 	this.setCurrentComponents('loginSuccess')
			// }

			// let roleData = this.roleData;
			// let sideList = this.asideList;
			// let loginData = this.loginData;
			
			// console.log(roleData,"roleData")
			
			
			
			// if (!(loginData && loginData.role_id)) {
			// 	for (let i = 0; i < sideList.length; i++) {
			// 		this.$set(sideList[i], 'hasLabel', true)
			// 	}
			// } else if (roleData) {
			// 	let dataList = JSON.parse(roleData);
			// 	for (let i = 0; i < sideList.length; i++) {
			// 		for (let j = 0; j < dataList.length; j++) {
			// 			if (dataList[j] == sideList[i].label) {
			// 				this.$set(sideList[i], 'hasLabel', true)
			// 			}
			// 		}
			// 	}
			// };
		},
		computed: {
			...mapState(['roleData','token','currentComponents','loginData'])
		},
		watch: {
			$route: {
				handler: function(val, oldVal){
					if(!this.token){
						this.loginOut();
					}
				},
				// 深度观察监听
				deep: true
			}
		},
		methods: {
			...mapMutations(['setRoleData','setToken','setCurrentComponents','setLoginData','loginOutState']),
			loginOut(data) {
				this.loginOutState('');
				this.setCurrentComponents('login');
				let sideList = this.asideList;
				for (let i = 0; i < sideList.length; i++) {
					this.$set(sideList[i], 'hasLabel', false)
				}
			},
			// 登录调用登录函数
			changeLoginStatus(data) {
				// this.currentComponents = data;
				let that = this;
				delete data.checkbox
				OperLogin(data).then(function(res) {
					let loginData = res.data;
					if (!loginData.token) return;
					let timer = 60 * 60 * 24;
					that.setToken(loginData.token);
					that.setCurrentComponents('loginSuccess');
					that.setLoginData(loginData.data);
					let sideList = that.asideList;
					
					if (loginData.data.role_id !== null) {
						
						RoleGetList({
							id: loginData.data.role_id
						}).then(function(res) {
							let roleData = res.data.data[0]?.role_value;
							let dataList = JSON.parse(roleData);

							for (let i = 0; i < sideList.length; i++) {
								for (let j = 0; j < dataList.length; j++) {
									if (dataList[j] == sideList[i].label) {
										that.$set(sideList[i], 'hasLabel', true)
									}
								}
							}
							
							that.setRoleData(roleData);
						})
					} else {
						for (let i = 0; i < sideList.length; i++) {
							that.$set(sideList[i], 'hasLabel', true)
						}
						that.setRoleData('false');
					}
				})
				// this.$router.push(this.$route.path + '?' + new Date().getTime());
				// this.$cookies.set('currentComponents',data);
				// console.log(data,this.$route.path,this.$cookies.get('currentComponents'),'data1246');
			}
		}
	}
</script>

<style lang="less" scoped>
</style>
