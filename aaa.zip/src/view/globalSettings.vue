<template>
	<el-container>
		<el-main>
			<form-update-find labelWidth='160px' :formUpdateFind="formUpdateFind">
				<el-button style="position: absolute;top: 0;right: 0;" slot="systemPasswordAfter" type="primary">读密码卡</el-button>
			</form-update-find>
		</el-main>
	</el-container>
</template>

<script>
	import mainFooter from "./commonTemplates/footer.vue";
	import formUpdateFind from "./commonTemplates/formUpdateFind.vue"
	export default {
		components: {
			mainFooter,
			formUpdateFind
		},
		data() {
			return {
				formUpdateFind: {
					company: {
						type: 'text',
						label: "公司名称：",
						value: "",
						require: false
					},
					concatTel: {
						type: 'text',
						label: "联系电话：",
						value: "",
						require: false
					},
					companySite: {
						type: 'text',
						label: "公司网址：",
						value: "",
						require: false
					},
					systemPassword: {
						type: 'password',
						label: "系统密钥：",
						value: "",
						require: false,
						slotAfter: true,
						slotAfterName: 'systemPasswordAfter'
					},
					autoReadCard: {
						type: 'checkbox',
						label: "",
						value: [],
						require: false,
						children: [{
								label: "自动读卡",
								value: "1"
							},
						],
					},
					autoReadCardGap: {
						type: 'text',
						label: "自动读卡间隔（ms）：",
						value: "",
						require: false
					},
					notWriteCard: {
						type: 'checkbox',
						label: "",
						value: [],
						require: false,
						children: [{
								label: "不写卡（勾选后，设备不能脱机）",
								value: "1"
							},
						],
					},
					fixedPost: {
						type: 'select',
						label: "时段固定补贴钱包",
						value: '',
						require: false,
						children: [{
								label: "补帖",
								value: "1"
							},
						],
					},
					openFace: {
						type: 'radio',
						label: "",
						value: "",
						require: false,
						children: [{
								label: "仅限刷卡",
								value: "1"
							},{
								label: "开启人脸消费",
								value: "2"
							},
						],
					},
					baseChangeCard: {
						type: 'checkbox',
						label: "",
						value: '',
						require: false,
						children: [{
								label: "不绑定卡片",
								value: "1"
							},
						],
					},
					autoPrint: {
						type: 'checkbox',
						label: "",
						value: '',
						require: false,
						children: [{
								label: "自动打印小票",
								value: "1"
							},
						],
					},
				}
			}
		},
		methods: {},
	}
</script>

<style>
</style>
