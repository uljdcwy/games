<template>
	<el-container>
		<el-main class="table-show">
			<el-row class="opera-list">
				<el-button size="small" type="primary" @click="showAddPersonInfo">新增</el-button>
				<el-button size="small" type="primary" @click="getList">刷新</el-button>
				<!-- 				<el-button size="small" type="primary">修改</el-button>
				<el-button size="small" type="primary">挂失</el-button>
				<el-button size="small" type="primary">解挂</el-button>
				<el-button size="small" type="primary" @click="changeCardInfo">换卡</el-button>
				<el-button size="small" type="primary" @click="destroyedCardNumber">注销</el-button>
				<el-button size="small" type="primary" @click="modifyPersonDept">批量改部门</el-button>
				<el-button size="small" type="primary">批量改级别</el-button>
				<el-button size="small" type="primary">批量挂失</el-button>
				<el-button size="small" type="primary">批量解挂</el-button>
				<el-button size="small" type="primary" @click="findPersonList">查询</el-button> -->
				<div style="float: right;">
					<el-input size="small" style="width: 150px;" v-model="searchName" placeholder="请输入用户名称">
					</el-input>
					<el-button size="small" type="primary" @click="searchList">搜索</el-button>
					<el-button size="small" type="primary" @click="showAdvSearch">高级搜索</el-button>
				</div>
			</el-row>

			<el-table stripe class="set-min-width" :data="tableData" @sort-change="sortChange" :height="tableMinHeight" style="width: 100%">
				<!-- <el-table-column type="selection" width="55">
				</el-table-column> -->
				<el-table-column sortable prop="user_name" label="用户名" min-width="120px">
				</el-table-column>
				<el-table-column sortable prop="phone" min-width="120px" label="手机号">
				</el-table-column>
				<el-table-column sortable prop="face_url" label="头像">
					<template slot-scope="scope">
						<el-button @click="lookPhoto(scope.row,scope.$index)" :disabled="!scope.row.face_url" size="small">查看</el-button>
					</template>
				</el-table-column>
				<el-table-column sortable prop="user_no" min-width="130px" label="用户编号">
				</el-table-column>
				<el-table-column sortable prop="moneyShow" min-width="130px" label="金额(元)">
				</el-table-column>
				<el-table-column sortable prop="card_id" min-width="120px" label="卡ID">
				</el-table-column>
				<el-table-column sortable prop="start_time" sortable label="开始时间" min-width="160px">
				</el-table-column>
				<el-table-column sortable prop="end_time" sortable label="结束时间" min-width="160px">
				</el-table-column>
				<el-table-column sortable prop="status" label="状态">
					<template slot-scope="scope">
						{{
							statusArr[scope.row.status]
						}}
					</template>
				</el-table-column>
				<!-- <el-table-column prop="level_id" label="级别">
				</el-table-column> -->
				<!-- <el-table-column prop="depositShow" label="押金(元)">
				</el-table-column> -->
				<el-table-column label="操作" fixed="right" width="260px">
					<template slot-scope="scope">
						<el-button type="primary" @click="recharge(scope.row,scope.$index)" size="small">人员卡管理
						</el-button>
						<el-button type="primary" @click="modifyData(scope.row,scope.$index)" size="small">修改
						</el-button>
						<el-button type="danger" @click="deleteData(scope.row,scope.$index)" size="small">注销</el-button>
					</template>
				</el-table-column>
			</el-table>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>

		<el-dialog class="dialog-box" :close-on-click-modal='false' :visible.sync="addPersonInfoStatus" :show-close='false'>
			<div slot="title">
				用户管理
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="addPersonInfoStatus = false"></i>
			</div>
			<el-form ref="formAdd" :rules="rules" :model="formAdd" label-width="80px">
				<el-row>
					<el-col :span="12">
						<el-form-item v-if="modifyStatus != 2" size="small" label="用户名称" prop="user_name">
							<el-input v-model="formAdd.user_name"></el-input>
						</el-form-item>
						<el-form-item v-if="modifyStatus == 2" size="small" label="用户名称">
							<el-input v-model="formAdd.user_name"></el-input>
						</el-form-item>
						<el-form-item v-if="modifyStatus != 2" size="small" label="用户编号" prop="user_no">
							<el-input type="number" v-model="formAdd.user_no" :disabled="modifyStatus == 3" onkeyup="this.value = this.value.toUpperCase()">
							</el-input>
						</el-form-item>
						<el-form-item v-if="modifyStatus == 2" size="small" label="用户编号">
							<el-input type="number" v-model="formAdd.user_no" :disabled="modifyStatus == 3" onkeyup="this.value = this.value.toUpperCase()">
							</el-input>
						</el-form-item>
						<el-form-item v-if="modifyStatus != 2" size="small" label="手机号" prop="phone">
							<el-input v-model="formAdd.phone"></el-input>
						</el-form-item>
						<el-form-item v-if="modifyStatus != 2" size="small" :required="!requireStatus" label="卡ID"
							prop="card_id">
							<el-input v-model="formAdd.card_id" onkeyup="this.value = this.value.toUpperCase()">
							</el-input>
						</el-form-item>
						<el-form-item size="small" v-if="modifyStatus != 2" label="选择时间" prop="selectTimeArr">
							<!-- <el-date-picker class="width-screen" value-format="yyyy-MM-dd HH:mm:ss"
								v-model="formAdd.start_time" align="right" type="date" placeholder="选择日期">
							</el-date-picker> -->
							<el-date-picker value-format="yyyy-MM-dd HH:mm:ss" style="width: 100%;" v-model="selectTimeArr" type="daterange" align="right" unlink-panels
								range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
							</el-date-picker>
						</el-form-item>
						<el-form-item size="small" v-if="modifyStatus == 2" label="开始时间">
							<!-- <el-date-picker class="width-screen" value-format="yyyy-MM-dd HH:mm:ss"
								v-model="" align="right" type="date" placeholder="选择日期">
							</el-date-picker>

							 --><el-date-picker value-format="yyyy-MM-dd HH:mm:ss" style="width: 100%;" v-model="startTimeArr" type="daterange" align="right" unlink-panels
								range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
							</el-date-picker>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item size="small" v-if="modifyStatus == 2" label="手机号" prop="phone">
							<el-input v-model="formAdd.phone"></el-input>
						</el-form-item>
						<el-form-item size="small" v-if="modifyStatus == 2" label="卡ID">
							<el-input v-model="formAdd.card_id" onkeyup="this.value = this.value.toUpperCase()">
							</el-input>
						</el-form-item>
						<el-form-item size="small" v-if="modifyStatus != 2" label="金额(元)" prop="money">
							<el-input-number style="width: 100%;" :controls="false" type="number" :min="0" v-model="formAdd.money"></el-input-number>
						</el-form-item>
						<el-form-item v-if="modifyStatus != 2" size="small" label="用户密码" prop="user_pass">
							<el-input v-model="formAdd.user_pass"></el-input>
						</el-form-item>
						<!-- <el-form-item v-if="modifyStatus != 2" size="small" label="用户等级" prop="level_id">
							<el-input type="number" v-model="formAdd.level_id"></el-input>
						</el-form-item> -->
						<el-form-item v-if="modifyStatus != 2" size="small" label="押金(元)" prop="deposit">
							<el-input-number style="width: 100%;" :controls="false" type="number" :min="0" v-model="formAdd.deposit"></el-input-number>
						</el-form-item>
						<el-form-item v-if="modifyStatus != 2" size="small" label="状态" prop="status">
							<el-select class="width-screen" v-model="formAdd.status" placeholder="请选择状态">
								<el-option v-for="(item, index) in statusArr" v-if="index" :key="index" :label="item"
									:value="index">
								</el-option>
							</el-select>
						</el-form-item>
						<!-- <el-form-item size="small" v-if="modifyStatus != 2" label="结束时间" prop="end_time">
							<el-date-picker class="width-screen" value-format="yyyy-MM-dd HH:mm:ss"
								v-model="formAdd.end_time" align="right" type="date" placeholder="选择日期">
							</el-date-picker>
						</el-form-item> -->
						<el-form-item size="small" v-if="modifyStatus == 2" label="结束时间">
							<!-- <el-date-picker class="width-screen" value-format="yyyy-MM-dd HH:mm:ss"
								v-model="formAdd.end_time" align="right" type="date" placeholder="选择日期">
							</el-date-picker> -->
							<el-date-picker value-format="yyyy-MM-dd HH:mm:ss" style="width: 100%;" v-model="endTimeArr" type="daterange" align="right" unlink-panels
								range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
							</el-date-picker>
						</el-form-item>
						<el-form-item :required="requireStatus" prop="face_url" v-if="modifyStatus != 2" size="small"
							label="上传图片">
							<el-upload class="upload-user" ref="upload" :before-remove="beforeRemove" :headers="{token: token}"
								:on-success="uploadSuccess" :before-upload="changeUpdate" :action="$http.options.root + '/api/upload'" :limit="1"
								:file-list="fileList">
								<el-button size="small" type="primary">点击上传</el-button>
								<div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过400kb</div>
							</el-upload>
						</el-form-item>
					</el-col>
				</el-row>
			</el-form>

			<span slot="footer" class="dialog-footer">
				<el-button v-if="modifyStatus == 3" size="small" @click="cancelPersonInfo">取 消</el-button>
				<el-button v-if="modifyStatus != 3" size="small" @click="resetPersonInfo">重 置</el-button>
				<el-button v-if="modifyStatus == 3" size="small" type="primary" @click="savePersonInfo">保 存</el-button>
				<el-button v-if="modifyStatus == 2" size="small" type="primary" @click="advSearch">搜 索</el-button>
				<el-button v-if="modifyStatus == 1" size="small" type="primary" @click="addPersonInfo">提 交</el-button>
			</span>
		</el-dialog>

		<el-dialog :visible.sync="lookPhotoStatus" :show-close='false'>
			<div slot="title">
				查看照片
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="lookPhotoStatus = false"></i>
			</div>
			<el-row style="text-align: center;">
				<el-image :src="photoUrl"></el-image>
			</el-row>
		</el-dialog>

		<el-dialog :close-on-click-modal='false' class="opera-list" :visible.sync="rechargeStatus" :show-close='false'>
			<div slot="title">
				人员卡管理
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="rechargeStatus = false"></i>
			</div>
			<el-tabs v-model="activeName">
				<el-tab-pane label="充值" name="first">
					<el-form ref="rechargeFrom" :model="rechargeFrom" label-width="100px">
						<el-form-item size="small" label="充值金额(元)" prop="recharge_money">
							<el-input-number style="width: 100%;" :controls="false" type="number" :min="0" v-model="rechargeFrom.recharge_money"></el-input-number>
						</el-form-item>
						<el-form-item size="small" style="display: none;" label="支付金额(元)" prop="pay_money">
							<el-input type="number" :min="0" v-model="rechargeFrom.pay_money"></el-input>
						</el-form-item>
						<!-- <el-form-item size="small" label="支付类型" prop="pay_type">
							<el-input v-model="rechargeFrom.pay_type"></el-input>
						</el-form-item> -->
					</el-form>
					<el-button size="small" @click="rechargeStatus = false">取 消</el-button>
					<el-button size="small" type="primary" @click="rechargeFromSubmit">提 交</el-button>
				</el-tab-pane>
				<el-tab-pane label="换卡" name="second">
					<el-form ref="changeCard" :model="changeCard" label-width="100px">
						<el-form-item size="small" label="新卡ID" :rules="[
      { required: true, message: '请输入新卡ID', trigger: 'blur' },
      { min: 8,max: 8, message: '请输入8位新卡ID', trigger: ['blur', 'change'] }
    ]" prop="new_card_id">
							<el-input v-model="changeCard.new_card_id" onkeyup="this.value = this.value.toUpperCase()">
							</el-input>
						</el-form-item>
						<el-form-item size="small" label="手续费(元)" prop="money">
							<el-input-number style="width: 100%;" :controls="false" type="number" :min="0" v-model="changeCard.money"></el-input-number>
						</el-form-item>
						<el-form-item size="small" label="换卡原因" prop="reason">
							<el-input type="textarea" v-model="changeCard.reason"></el-input>
						</el-form-item>
					</el-form>
					<el-button size="small" @click="rechargeStatus = false">取 消</el-button>
					<el-button size="small" type="primary" @click="changeCardSubmit">提 交</el-button>
				</el-tab-pane>
				<el-tab-pane label="挂失与解挂" name="third">
					<el-form ref="handUp" :model="handUp" label-width="90px">
						<el-form-item size="small" label="挂失与解挂" prop="dept_id">
							<el-select class="width-screen" v-model="handUp.oper_type" placeholder="请选择挂失与解挂">
								<el-option label="挂失" :value="1">
								</el-option>
								<el-option label="解挂" :value="2">
								</el-option>
							</el-select>
						</el-form-item>
					</el-form>
					<el-button size="small" @click="rechargeStatus = false">取 消</el-button>
					<el-button size="small" type="primary" @click="submitHandUp">提 交</el-button>
				</el-tab-pane>
				<!-- <el-tab-pane label="选择套餐" name="fourth">
					<el-form ref="bindOrUnBind" :model="bindOrUnBind" label-width="120px">
						<el-form-item size="small" label="先择绑定或解绑" prop="bindOrUnbind">
							<el-select v-model="bindOrUnBind.bindOrUnbind" placeholder="请选择绑写或解绑">
								<el-option label="绑定" :value="1">
								</el-option>
								<el-option label="解绑" :value="2">
								</el-option>
							</el-select>
						</el-form-item>
						<el-form-item size="small" label="选择套餐" prop="disount_package_id">
							<el-select v-model="bindOrUnBind.disount_package_id" placeholder="请选择套餐">
								<el-option v-for="(item,index) in rechargePackageArr" :label="item.name" :value="item.id">
								</el-option>
							</el-select>
						</el-form-item>
					</el-form>
					<el-button size="small" type="primary" @click="bindOrUnBindStatus = false">取 消</el-button>
					<el-button size="small" type="primary" @click="bindOrUnBindSubmit">提 交</el-button>
				</el-tab-pane> -->
			</el-tabs>
		</el-dialog>

	</el-container>
</template>

<script>
	import {
		apiupload,
		UserAdd,
		UserUpdate,
		UserDelete,
		UserRecharge,
		UserLostChannge,
		UserChanngeCard,
		UserGetList,
		DiscountPackageGetList,
		DiscountPackageCancelBindUser,
		DiscountPackageBindUser
	} from "./../http/http.js";
	
	import moveSelectBox from "./../mixins/moveSelectBox.js"

	import mainFooter from "./commonTemplates/footer.vue"
	import {
		mapMutations,
		mapState
	} from 'vuex'

	export default {
		components: {
			mainFooter
		},
		mixins: [moveSelectBox],
		data() {
			let that = this;
			return {
				searchNameStore: '',
				requireStatus: true,
				statusArr: ['', '正常', '挂失', '停用'],
				activeName: 'first',
				phone: '',
				bindOrUnBind: {
					disount_package_id: '',
					bindOrUnbind: ''
				},
				photoUrl: '',
				bindOrUnBindStatus: false,
				total: 0,
				currentPage: 1,
				pageSize: 15,
				rechargePackageArr: [],
				searchName: '',
				rechargeFrom: {
					id: '',
					recharge_money: '',
					pay_money: '',
					pay_type: 1
				},
				handUp: {
					oper_type: ''
				},
				selectTimeArr: [],
				changeCard: {
					new_card_id: "",
					money: '',
					reason: ""
				},
				userAddStatusArr: [{
						label: '启用',
						value: 1
					},
					{
						label: '未启用',
						value: 2
					}
				],
				fileList: [],
				newDept: '',
				transfer: [],
				levelsNameArr: [{
					label: '级别1',
					value: 1
				}],
				cardStatusArr: [{
					label: 'test1',
					value: 1
				}],
				deptNameArr: [{
					label: 'test',
					value: 1
				}],
				handUpStatus: false,
				addPersonInfoStatus: false,
				changeCardStatus: false,
				rechargeStatus: false,
				modifyPersonDeptData: {
					accountOpeningTime: ''
				},
				levelsArr: [{
					label: 'zheng',
					value: 1
				}, {
					label: 'zheng',
					value: 2
				}],
				ethnicInformationArr: [{
					label: 'zheng',
					value: 1
				}, {
					label: 'zheng',
					value: 2
				}],
				formAdd: {
					user_name: "",
					user_pass: "",
					phone: "",
					face_url: "",
					user_no: "",
					dept_id: '',
					money: '',
					card_id: "",
					start_time: "",
					end_time: "",
					status: '',
					level_id: '',
					deposit: ''
				},
				tableData: [],
				modifyStatus: 1,
				currentModify: '',
				lookPhotoStatus: false,
				startTimeArr: [],
				endTimeArr: [],
				rules: {
					status: [{
						required: true,
						validator: function(rule, value, callback) {
							if (value) {
								callback();
							} else {
								callback('请选择卡状态')
							}
						},
						trigger: 'blur'
					}],
					start_time: [{
						required: true,
						validator: function(rule, value, callback) {
							if (value) {
								callback();
							} else {
								callback('请选择开始时间')
							}
						},
						trigger: 'blur'
					}],
					end_time: [{
						required: true,
						validator: function(rule, value, callback) {
							if (value) {
								callback();
							} else {
								callback('请选择结束时间')
							}
						},
						trigger: 'blur'
					}],
					user_no: [{
						required: true,
						validator: function(rule, value, callback) {
							if (value?.length == 8) {
								callback();
							} else {
								callback('请输入8位数字用户编号')
							}
						},
						trigger: 'blur'
					}],
					card_id: [{
						required: false,
						validator: function(rule, value, callback) {
							if (value && that.requireStatus) {
								that.requireStatus = false;
								callback();
							}

							if (value?.length != 8 && !that.requireStatus) {
								callback('请输入8位数卡ID')
							} else {
								callback();
							}
						},
						trigger: 'change'
					}],
					face_url: [{
						required: false,
						validator: function(rule, value, callback) {
							if (value) {
								that.requireStatus = true;
								callback();
							}

							if (!value && that.requireStatus) {
								callback('请上传图片');
							} else {
								callback();
							}
						},
						trigger: 'change'
					}],
					user_name: [{
						required: true,
						validator: function(rule, value, callback) {
							console.log(value,"value123456")
							if (value) {
								callback();
							} else {
								callback('请输入用户名');
							}
						},
						trigger: 'blur'
					}],
					selectTimeArr: [{
						required: true,
						validator: function(rule, value, callback) {
							if (that.selectTimeArr[0]) {
								callback();
							} else {
								callback('请选择时间');
							}
						},
						trigger: 'blur'
					}]
				},
				card_id: '',
				user_no: ''
			}
		},
		computed: {
			...mapState(['token']),
			start_start_time(){
				return this.startTimeArr[0];
			},
			start_end_time(){
				return this.startTimeArr[1];
			},
			end_start_time(){
				return this.endTimeArr[0];
			},
			end_end_time(){
				return this.endTimeArr[1];
			},
		},
		watch: {
			selectTimeArr(newValue){
				this.formAdd.start_time = newValue[0];
				this.formAdd.end_time = newValue[1];
				return newValue
			}
		},
		created() {
			let that = this;
			that.getList();
			DiscountPackageGetList().then(function(res) {
				that.rechargePackageArr = res.data.data;
			})
		},
		methods: {
			sortChange(e){
				this.getList({
					SortField: e.prop,
					order: (e.order == 'ascending') ? 'ASC' : 'DESC'
				})
			},
			changeUpdate(file){
				if(file.size > 400000){
					this.$message.error('图片文件过大，请选择小于400KB的JPG,PNG格式图片')
					return false;
				}else{
					return true;
				};
			},
			beforeRemove() {
				this.formAdd.face_url = '';
			},
			bindOrUnBindSubmit() {
				let that = this;
				if (this.bindOrUnBind.bindOrUnbind == 1 && this.bindOrUnBind.disount_package_id !== '') {
					DiscountPackageBindUser({
						"user_id": that.currentModify.id,
						"disount_package_id": this.bindOrUnBind.disount_package_id
					}).then(function(res) {
						if (res.data.code == 1) {
							that.$message.success('绑定成功');
							that.getList();
						}
					})
				} else if (this.bindOrUnBind.bindOrUnbind == 2 && this.bindOrUnBind.disount_package_id !== '') {
					DiscountPackageCancelBindUser({
						"user_id": that.currentModify.id,
						"disount_package_id": this.bindOrUnBind.disount_package_id
					}).then(function(res) {
						if (res.data.code == 1) {
							that.$message.success('解绑成功');
							that.getList();
						}
					})
				} else {
					that.$message.warning('请选择正确的绑定方式或都套餐类型');
				}
				that.rechargeStatus = false;
			},
			bindOrUnBindShow() {
				this.bindOrUnBindStatus = true;
			},
			cancelPersonInfo() {
				this.addPersonInfoStatus = false;
			},
			resetPersonInfo() {
				for (let key in this.formAdd) {
					this.$set(this.formAdd, key, '');
				}
				this.selectTimeArr = [];
			},
			rechargeFromSubmit() {
				let that = this;
				let data = JSON.parse(JSON.stringify(this.rechargeFrom));
				data.id = this.currentModify.id;
				data.recharge_money = (data.recharge_money * 100);
				data.pay_money = data.recharge_money;
				UserRecharge(data).then(function(res) {
					if (res.data.code == 1) {
						that.$message.success('操作成功');
						that.rechargeStatus = false;
						that.getList();
					}
				})
			},
			changeCardSubmit() {
				let that = this;
				let data = JSON.parse(JSON.stringify(this.changeCard));
				data.user_id = this.currentModify.id;

				data.money = (data.money * 100);

				this.$refs?.changeCard?.validate(function(status) {
					if (status) {
						UserChanngeCard(data).then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('操作成功');
								that.rechargeStatus = false;
								that.getList();
							}
						})
					}
				})
			},
			submitHandUp() {
				let that = this;
				let userId = this.currentModify.id;
				let oper_type = this.handUp.oper_type;
				// console.log(userId,oper_type,"userId oper_type");
				UserLostChannge({
					"user_id": userId,
					"oper_type": oper_type
				}).then(function(res) {
					if (res.data.code == 1) {
						that.$message.success('操作成功');
						that.getList();
						that.rechargeStatus = false;
					}
				})
			},
			recharge(row, index) {
				this.currentModify = row;
				this.rechargeStatus = true;
				this.handUp.oper_type = (row.status == 1) ? 1 : 2;
			},
			advSearch() {
				
				console.log(this.start_start_time,'this.start_start_time',
				this.start_end_time,"this.start_end_time",
				this.end_end_time,"this.end_end_time",
				this.end_start_time,"this.end_start_time");
				
				this.getList({
					searchName: this.formAdd.user_name,
					phone: this.formAdd.phone,
					money: this.formAdd.money,
					start_time: this.start_start_time,
					end_time: this.start_end_time
				})
			},
			searchList() {
				this.getList({
					searchName: this.searchName
				})
			},
			showAdvSearch() {
				this.modifyStatus = 2;
				this.addPersonInfoStatus = true;
				this.fileList = [];
				this.resetPersonInfo();
				this.$refs.formAdd && this.$refs.formAdd.clearValidate();
			},
			deleteData(row, index) {
				let that = this;
				that.$confirm('<span>此操作将永久注销该用户</span></br><span>用户余额：<span style="color: #f00">' + (row.money / 100) + '</span> 元</span>', '警告', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					dangerouslyUseHTMLString: true,
					type: 'warning'
				}).then((actions) => {
					if (actions == 'confirm') {
						UserDelete({
							id: row.id
						}).then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('删除人员成功');
								that.getList();
							}
						})
					}
				})
			},
			modifyData(row, index) {
				this.addPersonInfoStatus = true;
				this.modifyStatus = 3;
				this.fileList = [];
				for (let key in this.formAdd) {
					if (key == 'money') {
						this.$set(this.formAdd, key, (row[key] / 100).toFixed(2));
						continue;
					}
					if (key == 'deposit') {
						this.$set(this.formAdd, key, (row[key] / 100).toFixed(2));
						continue;
					}
					this.$set(this.formAdd, key, row[key]);
				};
				this.currentModify = row;
				this.selectTimeArr = [row.start_time,row.end_time]
				this.$refs.formAdd && this.$refs.formAdd.clearValidate();
			},
			uploadSuccess(data) {
				this.formAdd.face_url = data.filename;
			},
			savePersonInfo() {
				let that = this;
				let data = JSON.parse(JSON.stringify(this.formAdd));
				data.id = this.currentModify.id;

				data.money = (data.money * 100);
				data.deposit = (data.deposit * 100);

				UserUpdate(data).then(function(res) {
					if (res.data.code == 1) {
						that.$message.success('修改人员成功');
						that.getList();
					}
				})
			},
			addPersonInfo() {
				let that = this;
				let data = JSON.parse(JSON.stringify(this.formAdd));

				this.$refs.formAdd.validate(function(valid) {
					if (valid) {
						data.money = (data.money * 100)
						data.deposit = (data.deposit * 100)

						UserAdd(data).then(function(res) {
							if (res.data.code == 1) {
								that.$message.success('添加人员成功');
								that.getList();
							}
						})
					}
				})
			},
			changeCardInfo() {
				this.changeCardStatus = true;
			},
			showAddPersonInfo() {
				this.addPersonInfoStatus = true;
				this.modifyStatus = 1;
				this.fileList = [];
				this.resetPersonInfo();
				let that = this;
				this.$nextTick(function() {
					that.$refs.formAdd.clearValidate();
				})
			},
			getList(data) {
				let that = this;
				data = data || {};
				
				// 点击了高级搜索
				if (this.modifyStatus == 2 && this.addPersonInfoStatus) {
					this.searchNameStore = this.formAdd.user_name;
					this.phone = this.formAdd.phone;
					this.card_id = this.formAdd.card_id;
					this.user_no = this.formAdd.user_no;
				}else if(data.searchName == '' || data.searchName){
					this.startTimeArr = ['',''];
					this.endTimeArr = ['',''];
					this.selectTimeArr = ['',''];
					this.resetPersonInfo();
					this.phone = '';
					this.searchNameStore = data.searchName;
					this.card_id = '';
					this.user_no = '';
				}
				

				that.currentPage = data.currentPage || that.currentPage
				that.pageSize = data.pageSize || that.pageSize
				
				
				console.log(data,"data.SortOrder")
				
				if(data.SortField == 'moneyShow'){
					data.SortField = 'money'
				}
				
				UserGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": data.SortField || "user_name",
					"SortOrder": data.order || "DESC",
					"user_name": this.searchNameStore || '',
					"phone": this.phone || '',
					"start_time": this.start_start_time || '',
					"end_time": this.start_end_time || '',
					"end_end_time": this.end_end_time || '',
					"start_end_time": this.end_start_time || '',
					"card_id": this.card_id,
					"user_no": this.user_no
				}).then(function(res) {
					let data = res.data.data;
					for (let i = 0; i < data?.length; i++) {
						data[i].moneyShow = (data[i].money / 100).toFixed(2);
						data[i].depositShow = (data[i].deposit / 100).toFixed(2);
					}
					that.tableData = data;
					that.total = res.data.count;
					that.addPersonInfoStatus = false;
				})
			},
			cancelAdd() {

			},
			submitAdd() {

			},
			lookPhoto(row, index) {
				this.lookPhotoStatus = true;
				this.photoUrl = this.$http.options.root + "/hpt/v2/" + row.face_url;
			},
		},
	}
</script>

<style lang="scss" scoped>
	.new-dept {
		width: 80px;
		display: inline-block;
	}

	.modify-button {
		margin-top: 20px;
	}

	.transfer-span {
		display: inline-block;
		width: 60px;
	}

	.opera-list {
		border-bottom: 1px solid #ccc;
		padding-bottom: 10px;
	}

	.transfer-box {
		display: inline-block;
		text-align: left;
	}

</style>
