<template>
	<el-container>
		<el-main>
			<form-update-find labelWidth='120px' :formUpdateFind="formUpdateFind">
			</form-update-find>
		</el-main>
	</el-container>
</template>

<script>
	import formUpdateFind from "./commonTemplates/formUpdateFind.vue"
	export default {
		components: {
			formUpdateFind
		},
		data() {
			return {
				formUpdateFind: {
					userName: {
						type: 'text',
						label: "默认开卡金额",
						value: "",
						require: false
					},
					password: {
						type: 'password',
						label: "默认查询密码",
						value: "",
						require: false
					},
					baseWXPINCode: {
						type: 'text',
						label: "默认微信PIN码",
						value: "",
						require: false
					},
					personCodeLength: {
						type: 'text',
						label: "人员编号长度",
						value: "",
						require: false
					},
					personNumberPre: {
						type: 'text',
						label: "人员编号前缀",
						value: "",
						require: false
					},
					baseDept: {
						type: 'select',
						label: "默认部门",
						value: "",
						require: false,
						children: [{
								label: "123",
								value: "1"
							},
							{
								label: "sfs",
								value: "2"
							},
							{
								label: "zheng",
								value: "3"
							},
						],
					},
					baseLevels: {
						type: 'select',
						label: "默认级别",
						value: "",
						require: false,
						children: [{
								label: "123",
								value: "1"
							},
							{
								label: "sfs",
								value: "2"
							},
							{
								label: "zheng",
								value: "3"
							},
						],
					},
					baseChangeCard: {
						type: 'text',
						label: "默认换卡交费",
						value: "",
						require: false
					},
					baseLevels: {
						type: 'select',
						label: "默认级别",
						value: "",
						require: false,
						children: [{
								label: "123",
								value: "1"
							},
							{
								label: "sfs",
								value: "2"
							},
							{
								label: "zheng",
								value: "3"
							},
						],
					},
					baseChangeCard: {
						type: 'checkbox',
						label: "销卡设置",
						value: [],
						require: false,
						children: [{
								label: "销户时自动清卡",
								value: "1"
							},
							{
								label: "销户时默认退押金",
								value: "2"
							},
							{
								label: "销户时默认退还现金余额",
								value: "3"
							},
							{
								label: "销户时默认退还补贴余额",
								value: "4"
							},
							{
								label: "销户时默认清未使用订餐",
								value: "5"
							},
							{
								label: "销户成功后关闭窗口",
								value: "6"
							},
						],
					},
				},
			}
		},
		methods: {
		},
	}
</script>

<style>
</style>
