<template>
	<el-row>
		<input type="file" ref="fileUpdate" @change="fileUpdate">
	</el-row>
</template>

<script>
	import {
		read,
		writeFileXLSX
	} from "xlsx";
	export default {
		name: 'ImportPersonnelData',
		data() {
			return {
				file: null
			}
		},
		methods: {
			fileUpdate(e) {
				console.log(read, "read");
				if (e.target.files.length > 0) {
					const file = e.target.files[0];
					const fileName = e.target.files[0].name;
					const fileArr = fileName.split('.');
					const fileSuffix = fileArr[fileArr.length - 1];
					if (fileSuffix === 'xlsx' || fileSuffix === 'xls') {
						// 解析数据
						const reader = new FileReader();
						reader.onload = (e) => {
							/* Parse data */
							const bstr = e.target.result;
							const wb = read(bstr, {
								type: 'binary'
							});
							
							
							let sheets = wb.Sheets.Sheet1
							let sheetsCons = wb.SheetNames
							
							console.log(sheets,sheetsCons,"123456789")
							

						};
						reader.readAsBinaryString(file);
					} else {
						console.log('不支持该格式的解析');
					}
				} else {
					console.log('请选择文件上传');
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
</style>
