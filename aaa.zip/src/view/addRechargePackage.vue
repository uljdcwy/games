<template>
	<el-container>
		<el-main>
			<data-add-del-mod-find @resetDialog="resetDialog" :tableDataObj="tableDataObj" @addData="rechargeAdd"
				:dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj"
				@getList="getList" @showDialog="showDialog" @saveModifyBtn="saveModifyBtn">
				<div slot="opera" slot-scope="porps">
					<el-button size="small" type="primary" @click="modifyData(porps)">修改</el-button>
				</div>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		DiscountPackageAdd,
		DiscountPackageUpdate,
		DiscountPackageGetList
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				pageSize: 15,
				currentPage: 0,
				fromDataObj: {
					opera: false,
					title: "套餐管理",
					searchPlaceholder: "请输入套餐名称",
					formList: {
						name: {
							type: 'text',
							label: "套餐名称",
							value: "",
							require: true,
							msg: "请输入套餐名称",
							searchAdv: true
						},
						strart_time: {
							type: 'datePicke',
							label: "开始时间",
							value: "",
							require: true,
							msg: "请输入开始时间",
							searchAdv: false
						},
						end_time: {
							type: 'datePicke',
							label: "结束时间",
							value: "",
							require: true,
							msg: "请输入开始时间",
							searchAdv: false
						},
						recharge_money: {
							type: 'text',
							label: "充值金额",
							value: "",
							require: true,
							msg: "请输入充值金额",
							searchAdv: true
						},
						pay_money: {
							type: 'text',
							label: "支付金额",
							value: "",
							require: true,
							msg: "请输入支付金额",
							searchAdv: true
						},
						remark: {
							type: 'text',
							label: "备注",
							value: "",
							require: false,
							msg: "请输入备注",
							searchAdv: false
						},
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: true,
					selection: false,
					index: false,
					columnList: [{
						prop: 'name',
						width: false,
						label: '套餐名称',
						slot: false,
						sortable: false,
					}, {
						prop: 'strart_time',
						width: false,
						label: '开始时间',
						slot: false,
						sortable: false
					}, {
						prop: 'end_time',
						width: false,
						label: '结束时间',
						slot: false,
						sortable: false
					}, {
						prop: 'recharge_money',
						width: false,
						label: '充值金额',
						slot: false,
						sortable: false
					}, {
						prop: 'pay_money',
						width: false,
						label: '支付金额',
						slot: false,
						sortable: false
					}, {
						prop: 'remark',
						width: false,
						label: '备注',
						slot: false,
						sortable: false
					}],
					tableData: []
				},
				currentID: ''
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
		},
		methods: {
			resetDialog() {
				let data = this.fromDataObj.formList;
				for (let key in data) {
					this.fromDataObj.formList[key].value = '';
				}
			},
			modifyData(porps) {
				this.dialogVisible = true;
				this.dialogStatus = 3;
				this.currentID = porps.opera.id;
				this.fromDataObj.formList.name.value = porps.opera.name;
				this.fromDataObj.formList.pay_money.value = porps.opera.pay_money;
				this.fromDataObj.formList.recharge_money.value = porps.opera.recharge_money;
				this.fromDataObj.formList.remark.value = porps.opera.remark;
				this.fromDataObj.formList.strart_time.value = porps.opera.strart_time;
				this.fromDataObj.formList.end_time.value = porps.opera.end_time;
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if (obj.advSearch) {
					obj.searchName = obj.name.value;
				}

				DiscountPackageGetList({
					"PageIndex": obj.currentPage || that.currentPage,
					"PageSize": obj.pageSize || that.pageSize,
					"SortField": obj.SortField || "name",
					"SortOrder": obj.SortOrder || "DESC",
					'name': obj.searchName || '',
					'recharge_money': obj.recharge_money?.value || '',
					'pay_money': obj.pay_money?.value || ''
				}).then(function(res) {
					that.tableDataObj.tableData = res.data.data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			rechargeAdd(data) {
				let that = this;
				DiscountPackageAdd({
					"name": data.name.value,
					"strart_time": data.strart_time.value,
					"end_time": data.end_time.value,
					"recharge_money": data.recharge_money.value,
					"pay_money": data.pay_money.value,
					"remark": data.remark.value
				}).then(function(res) {
					if(res.data.code == 1){
						that.$message.success('添加套餐成功');
						that.getList();
					}
				})
			},
			showDialog(index) {
				if (index === '') {
					this.dialogVisible = false;
				} else {
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
			saveModifyBtn(data) {
				let that = this;
				console.log(data, "data123456");
				DiscountPackageUpdate({
					"id": this.currentID,
					"name": data.name.value,
					"strart_time": data.strart_time.value,
					"end_time": data.end_time.value,
					"recharge_money": data.recharge_money.value,
					"pay_money": data.pay_money.value,
					"remark": data.remark.value
				}).then(function(res) {
					if(res.data.code == 1){
						that.$message.success('修改套餐成功');
						that.getList();
					}
				})

			}
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
