<template>
	<el-container>
		<el-main>
			<data-add-del-mod-find :tableHeight="tableMinHeight" :addData="false" @resetDialog="resetDialog" :tableDataObj="tableDataObj" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList"
				@showDialog="showDialog">
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList"></main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		CancellationRecordGetList
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				pageSize: 15,
				currentPage: 1,
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "用户注销记录",
					searchPlaceholder: "请输入用户名称",
					formList: {
						user_name: {
							type: 'text',
							label: "用户名称",
							value: "",
							require: true,
							msg: "请输入用户名称",
							searchAdv: true
						},
						card_id: {
							type: 'text',
							label: "卡ID",
							value: "",
							require: true,
							msg: "请输入卡ID",
							searchAdv: true
						},
						start_oper_time: {
							type: 'datePicke',
							label: "开始时间",
							value: "",
							searchAdv: true
						},
						end_oper_time: {
							type: 'datePicke',
							label: "结束时间",
							value: "",
							searchAdv: true
						}
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: false,
					selection: false,
					index: false,
					columnList: [{
						prop: 'user_name',
						width: '120px',
						label: '用户名称',
						slot: false,
						sortable: true,
					},
					{
						prop: 'card_id',
						width: '100px',
						label: '卡ID',
						slot: false,
						sortable: true,
					},{
						prop: 'money',
						width: '120px',
						label: '金额（元）',
						slot: false,
						sortable: true,
					},{
						prop: 'deposit',
						width: '120px',
						label: '押金（元）',
						slot: false,
						sortable: true,
					},{
						prop: 'remark',
						width: '180px',
						label: '备注',
						slot: false,
						sortable: true,
					},{
						prop: 'oper_time',
						width: '160px',
						label: '操作时间',
						slot: false,
						sortable: true,
					}],
					tableData: []
				},
				currentID: ''
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
		},
		methods: {
			resetDialog(){
				let data = this.fromDataObj.formList;
				for(let key in data){
					this.fromDataObj.formList[key].value = '';
				}
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if(obj.advSearch){
					this.searchName = obj.user_name.value;
				}else if(obj.searchName === '' || obj.searchName){
					this.resetDialog();
					this.searchName = obj.searchName;
				}
				
				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize
				
				CancellationRecordGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "user_name",
					"SortOrder": obj.SortOrder || "DESC",
					'user_name': this.searchName || '',
					"card_id": this.fromDataObj.formList.card_id?.value || '',
					'start_oper_time': this.fromDataObj.formList.start_oper_time?.value || '',
					'end_oper_time': this.fromDataObj.formList.end_oper_time?.value || ''
				}).then(function(res){
					let data = res.data.data;
					for(let i = 0; i < data.length; i++){
						data[i].deposit = (data[i].deposit / 100).toFixed(2);
						data[i].money = (data[i].money / 100).toFixed(2);
					}
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index){
				if(index === ''){
					this.dialogVisible = false;
				}else{
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
