<template>
	<el-form :model="ruleForm" ref="ruleForm" label-width="100px" class="card-ruleForm">
		<el-form-item size="small" label="管理介质">
			<el-select v-model="ruleForm.manage">
				<el-option label="人脸" :value="0"></el-option>
				<el-option label="指纹" :value="1"></el-option>
				<el-option label="卡片" :value="2"></el-option>
			</el-select>
		</el-form-item>
		<el-form-item size="small"  v-if="ruleForm.manage === 0">
			<el-button type="primary">采集人脸</el-button>
		</el-form-item>
		<el-form-item size="small"  v-if="ruleForm.manage === 1">
			<el-button type="primary">采集指纹</el-button>
		</el-form-item>
		<el-form-item size="small"  v-if="ruleForm.manage === 2" :label="ruleForm.manage === 2 ? '卡号' : ''">
			<el-input type="text" v-model="ruleForm.readCardValue"></el-input>
			<el-button style="position: absolute;top: 0;right: 0;" type="primary">读卡</el-button>
		</el-form-item>
		<el-form-item size="small" label="类型">
			<el-select v-model="ruleForm.cardType">
				<el-option label="充值管理卡" :value="0"></el-option>
			</el-select>
		</el-form-item>
		<el-form-item size="small" label="操作员">
			<el-select v-model="ruleForm.operaPerson">
				<el-option label="admin" :value="0"></el-option>
			</el-select>
		</el-form-item>
		
		<el-form-item>
			<el-button type="primary" size="small" @click="submitForm('ruleForm')">立即创建</el-button>
			<el-button size="small" @click="resetForm('ruleForm')">重置</el-button>
		</el-form-item>
	</el-form>
</template>

<script>
	export default {
		name: "managementCard",
		data(){
			return {
				ruleForm: {
					manage: 0,
					readCardValue: '',
					cardType: '',
					operaPerson: ''
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.card-ruleForm{
		padding-top: 15px;
	}
</style>
