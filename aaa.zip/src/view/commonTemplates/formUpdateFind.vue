<template>
	<div class="form-update-find">
		<el-form ref="formUpdateFind" :model="formUpdateFind" :label-width="labelWidth">
			<template v-for="(item,index) in formUpdateFind">
				<el-form-item size="small" v-if="item.type == 'text'" :label="item.label" :prop="index" :placeholder="item.placeholder"  :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-input type="text" v-model="item.value"></el-input>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'button'" :label="item.label" :prop="index" :placeholder="item.placeholder"  :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-button type="primary">{{item.content}}</el-button>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'select'" :label="item.label" :prop="index"  :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-select v-model="item.value" :placeholder="item.placeholder">
						<el-option v-for="(itemChild,itemIndex) in item.children" :label="itemChild.label" :value="itemChild.value"></el-option>
					</el-select>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'password'" :label="item.label" :prop="index" :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-input type="password" v-model="item.value" :placeholder="item.placeholder"></el-input>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'radio'" :label="item.label" :prop="index" :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-radio-group v-model="item.value">
						<el-radio v-for="(itemChild, indexChild) in item.children" :label="itemChild.label">
						</el-radio>
					</el-radio-group>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'textarea'" :label="item.label" :prop="index" :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-input type="textarea" v-model="item.value" :placeholder="item.placeholder"></el-input>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
				<el-form-item size="small" v-if="item.type == 'checkbox'" :label="item.label" :prop="index" :rules="{required: item.require, validator: item.validator, trigger: 'blur' }">
					<el-checkbox-group v-model="item.value">
						<el-checkbox v-for="(itemChild, indexChild) in item.children" :label="itemChild.label"
							name="type" :value="itemChild.value"></el-checkbox>
					</el-checkbox-group>
					<slot v-if="item.slotAfter" :name="item.slotAfterName"></slot>
				</el-form-item>
			</template>
			
			<el-form-item>
				<el-button size="small" type="primary" @click="onSubmit">保存</el-button>
				<el-button size="small">重置</el-button>
			</el-form-item>
		</el-form>
	</div>
</template>

<script>
	export default {
		props: {
			labelWidth: {
				type: String,
				default: '80px'
			},
			formUpdateFind: {
				type: Object,
				default: function(){
					return {
						
					}
				}
			}
		},
		data() {
			return {}
		},
		methods: {
			onSubmit(){
				this.$emit('submit',)
			}
		},
	}
</script>

<style lang="scss" scoped>
</style>
