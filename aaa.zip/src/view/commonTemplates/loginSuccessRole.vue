<template>
	<el-container>

		<el-aside width="220px">
			<main-aside :asideList="asideList"></main-aside>
		</el-aside>
		<el-container>
			<el-header class="main-header" height="50px">
				<main-header :title="title" :logo="logo">
					<template slot="opera">
						<div class="opera">
							<span style="font-size: 12px;color: #666;display: inline-block;margin-right: 5px;">
								帐号：{{loginData.account}}
							</span>
							<span style="font-size: 12px;color: #666;display: inline-block;margin-right: 5px;">
								角色：<el-link style="font-size: 12px;vertical-align: baseline;" :underline="false"
									@click="selectRole">{{roleName}}</el-link>
							</span>
							<el-link @click="loginOut" :underline="false">
								退出登录
							</el-link>
						</div>
					</template>
				</main-header>
			</el-header>
			<el-dialog title="选择角色" :visible.sync="showSelectRole" :close-on-click-modal="false">
				<div style="display: inline-block;">选择角色：</div>
				<el-select style="    display: inline-block;
    width: 260px;" size="small" v-model="roleId" placeholder="请选择角色">
					<el-option v-for="(item, index) in roleList" :key="index" :label="item.role_name" :value="item.id">
					</el-option>
				</el-select>
				<span slot="footer" class="dialog-footer">
					<el-button @click="showSelectRole = false">取 消</el-button>
					<el-button type="primary" @click="submitRoleId">提 交</el-button>
				</span>
			</el-dialog>
			<router-view></router-view>
		</el-container>
	</el-container>
</template>

<script>
	import mainAside from './aside.vue';
	import mainHeader from './header.vue';

	import {
		RoleGetList,
		OperGetList,
		OperUpdate
	} from "./../../http/http.js"

	import {
		mapState
	} from 'vuex'
	export default {
		name: 'loginSuccess',
		props: {
			title: {
				type: String,
				default: ''
			},
			asideList: {
				type: Array,
				default: function() {
					return [

					]
				}
			},
			logo: {
				type: String,
				default: ''
			}
		},
		components: {
			mainAside,
			mainHeader
		},
		data() {
			return {
				showSelectRole: false,
				roleName: '',
				roleList: [],
				roleId: '',
				accountData: ''
			}
		},
		computed: {
			...mapState(['loginData'])
		},
		mounted() {
			let that = this;
			RoleGetList().then(function(res) {
				if (res.data.code == 1) {
					let data = res.data.data;
					that.roleList = data;
					for (let i = 0; i < data.length; i++) {
						if (that.loginData.role_id == data[i].id) {
							that.roleName = data[i].role_name;
							break;
						}
					}
				}
			});
			window.onresize = function() {
				setTimeout(function() {
					let htmlEl = document.getElementsByTagName('html')[0];
					document.body.setAttribute("style", "height:" + that.getStyle(htmlEl, 'height'))
				}, 100)
			}
		},
		methods: {
			getStyle(obj, attr) {
				if (obj.currentStyle) {
					return obj.currentStyle[attr]
				} else {
					return document.defaultView.getComputedStyle(obj, null)[attr]
				}
			},
			loginOut() {
				this.$emit('loginOut', 'login')
			},
			// 显示选择权限
			selectRole() {
				// this.showSelectRole = true;
				// let that = this;
				// OperGetList({
				// 	PageIndex: 0,
				// 	PageSize: 15,
				// 	SortField: "account",
				// 	SortOrder: "DESC",
				// 	account: this.loginData.account
				// }).then(function(res){
				// 	if(res.data.code == 1){
				// 		that.accountData = res.data.data[0];
				// 	}
				// })
			},
			submitRoleId(){
				let that = this;
				if(!this.roleId && this.roleId !== 0){
					this.$message.error("请选择角色")
					return null
				}
				this.accountData.role_id = this.roleId;
				
				OperUpdate(JSON.parse(JSON.stringify(this.accountData))).then(function(res){
					if(res.data.code == 1){
						that.selectRole();
						that.loginOut();
					}
				})
				// 此时获取更新权限ID
			},
		}
	}
</script>

<style lang="less" scoped>
	.main-header {
		border-bottom: 1px solid #ccc;
		line-height: 50px;
	}

	.opera {
		float: right;
	}

	.footer-pagination {
		line-height: 40px;
		border-top: 1px solid #ccc;
		padding-top: 10px;
		text-align: center;
	}
</style>
