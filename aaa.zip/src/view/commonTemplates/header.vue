<template>
	<div class="header-box">
		<slot name="opera" class="opera"></slot>
		<el-image v-if="logo" class="logo" :src="logo"></el-image>
		<span class="system-title">{{title}}</span>
	</div>
</template>

<script>
	export default {
		name: 'hedTop',
		props: {
			logo: {
				type: String,
				default: ''
			},
			title: {
				type: String,
				default: "标题"
			}
		},
		methods: {
		}
	}
</script>
<style>
	.logo {
		line-height: 1;
		img {
			height: 48px;
		}
	}
</style>
<style lang="scss" scoped>
	.system-title{
		display: inline-block;
		vertical-align: top;
		font-weight: bold;
	}
</style>
