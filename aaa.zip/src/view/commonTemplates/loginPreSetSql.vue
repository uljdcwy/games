<template>
	<el-main class="login">
		<div class="login-from-box">
			<div class="from-title">
				{{title}}
			</div>
			<el-form ref="FormData" :rules="rules" :model="FormData" :label-width="labelWidth">
				<el-form-item label="帐号" prop="account">
					<el-input v-model="FormData.account">
						<i slot="prepend" class="el-icon-user-solid"></i>
						</el-button>
					</el-input>
				</el-form-item>
				<el-form-item label="密码" prop="password">
					<el-input type="password" @focus="addEnter" @blur="removeEnter" v-model="FormData.password">
						<i slot="prepend" class="el-icon-lock"></i>
					</el-input>
				</el-form-item>
				<!-- <el-form-item class="checkbox">
					<el-checkbox v-model="FormData.checkbox" class="checkbox-content" label="记住密码" name="type">
					</el-checkbox>
				</el-form-item> -->
				<el-form-item>
					<el-button class="login-btn" type="primary" @click="login">登 录</el-button>
				</el-form-item>
			</el-form>
		</div>

		<el-dialog :visible.sync="setSqlAddressStatus" :close-on-click-modal="false" :show-close='false'>
			<div slot="title">
				数据库连接失败请重新设置数据库
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="setSqlAddressStatus = false"></i>
			</div>
			<el-form ref="formSql" label-width="120px" :model="form">
				<el-form-item label="数据库IP地址" prop="ip" :rules="[{required: true,message: '请输入数据库IP地址', trigger: 'blur'}]">
					<el-input v-model="form.ip"></el-input>
				</el-form-item>
				<el-form-item label="端口号" prop="port" :rules="[{required: true, message: '请输入端口号', trigger: 'blur' }]">
					<el-input v-model="form.port"></el-input>
				</el-form-item>
				<el-form-item label="用户名" prop="user" :rules="[{required: true, message: '请输入用户名', trigger: 'blur' }]">
					<el-input v-model="form.user"></el-input>
				</el-form-item>
				<el-form-item label="密码" prop="password" :rules="[{required: true, message: '请输入密码', trigger: 'blur' }]">
					<el-input type="password" v-model="form.password"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="setSqlAddressStatus = false">取 消</el-button>
				<el-button type="primary" @click="submitFormSql">提 交</el-button>
			</div>
		</el-dialog>
	</el-main>
</template>

<script>
	
	import {
		sysTestDBConnect,
		sysCreateDB
	} from "../../http/http.js";
	
	export default {
		name: 'login',
		props: {
			title: {
				type: String,
				default: ""
			}
		},
		data() {
			return {
				form: {
					ip: '',
					port: 3306,
					user: 'root',
					password: ''
				},
				setSqlAddressStatus: false,
				labelWidth: '60px',
				FormData: {
					account: "",
					password: "",
					checkbox: false
				},
				rules: {
					account: [{
						required: true,
						message: '帐号不能为空',
						trigger: 'change'
					}],
					password: [{
						required: true,
						message: '密码不能为空',
						trigger: 'change'
					}],
				},
				index: 0
			}
		},
		mounted() {
			this.testConnect();
		},
		methods: {
			testConnect(){
				let that = this;
				sysTestDBConnect().then(function(res){
					res.loadingStatus?.close();
					that.setSqlAddressStatus = false;
					that.$message.success(res.data.msg);
				},function(err){
					err.loadingStatus?.close();
					that.index += 1;
					that.$message.error("连接失败再次尝试中，自动尝试三次之后将提示您更改数据库IP地址");
					if(that.index > 2){
						that.setSqlAddressStatus = true;
						return null;
					}
					setTimeout(function(){
						that.testConnect();
					},3000)
				})
			},
			submitFormSql() {
				let that = this;
				this.$refs.formSql.validate(function(valid) {
					if (valid) {
						// 发送创建数据库请求
						sysCreateDB(that.form).then(function(res){
							if(res.data.code == 1){
								that.$message.success("数据库创建成功请关闭系统后重新登录")
							}
						})
					}
				})
			},
			addEnter(e) {
				let that = this;
				window.onkeyup = function(e) {
					if (e.keyCode == 13) {
						that.login();
					}
				}
			},
			removeEnter(e) {
				window.onkeyup = null;
			},
			login() {
				let that = this;
				this.$refs['FormData'].validate((valid) => {
					if (valid) {
						let data = JSON.parse(JSON.stringify(this.FormData));
						that.$emit('changeLoginStatus', data)
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			reset() {
				console.log("login reset");
			}
		}
	}
</script>
<style lang="less">
	.login {
		.el-form {}

		.el-form {
			.checkbox {
				margin-top: -10px;

				.el-form-item__content {
					line-height: 20px;
					height: 20px;
				}
			}
		}
	}
</style>

<style lang="scss" scoped>
	.login {
		height: 100%;
		width: 100%;

		.login-from-box {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translateY(-50%) translateX(-50%);
			max-width: 400px;
			padding: 10px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
			border-radius: 10px;
			width: 100%;

			.from-title {
				text-align: center;
				padding: 10px 0 15px;
				margin-bottom: 20px;
				border-bottom: 1px solid #ccc;

			}

			.login-btn {
				width: 100%;
			}
		}
	}
</style>
