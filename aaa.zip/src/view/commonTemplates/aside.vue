<template>
	<el-menu router class="el-menu-vertical-aside">
		<template v-for="(item,Index) in asideList">
			<el-submenu v-if="item.children" :hidden="!item.hasLabel" :index="Index + ''">
				<template slot="title">
					<i v-if="item.icon" :class="item.icon"></i>
					<span>{{item.label}}</span>
				</template>
				<el-menu-item v-for="(itemChild, indexChild) in item.children" :path="itemChild.path" :class="routePath == itemChild.path ? 'is-active' : ''" :index="Index + '-' + indexChild" :route="{path: itemChild.path}">
					{{itemChild.label}}</el-menu-item>
			</el-submenu>
			<el-menu-item v-if="!item.children" :path="item.path" :class="routePath == item.path ? 'is-active' : ''" :hidden="!item.hasLabel"  :index="Index + ''" :route="{path: item.path}">
				<i v-if="item.icon" :class="item.icon"></i>
				<span slot="title">{{item.label}}</span>
			</el-menu-item>
		</template>
	</el-menu>
</template>

<script>
	export default {
		name: 'aid',
		props: {
			asideList: {
				type: Array,
				default: function() {
					return [{
						label: 'label',
						path: 'path'
					}]
				}
			}
		},
		watch: {
			$route: {
				handler: function(val, oldVal){
					this.routePath = val.path;
				},
			}
		},
		mounted() {
			this.routePath = this.$route.path;
		},
		data() {
			return {
				routePath: ''
			};
		},
		methods: {
		}
	}
</script>

<style lang="less" scoped>
	.el-menu-vertical-aside{
		height: 100%;
	}
</style>
