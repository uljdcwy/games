<template>
	<el-row>
		<el-row class="main-title">
			<el-col :span="8">
				<el-button v-if="addData" size="small" type="primary" @click="showDialog(1)">新增</el-button>
				<slot name="manyOpera"></slot>
				<el-button size="small" type="primary" @click="resetLoadData">刷新</el-button>
			</el-col>
			<el-col :span="16" class="search-box">
				<el-input size="small" v-model="search" style="width: 150px;" @keyup.enter="searchSign"
					:placeholder="fromDataObj.searchPlaceholder">
				</el-input>
				<el-button size="small" type="primary" @click="searchSign">搜索</el-button>
				<el-button size="small" type="primary" @click="showDialog(2)">高级搜索</el-button>
			</el-col>
		</el-row>
		<el-col :span="24">
			<el-table stripe :data="tableDataObj.tableData" :height="tableHeight" @sort-change="sortChange" @selection-change="handleSelectionChange"
				style="width: 100%">
				<el-table-column v-if="tableDataObj.selection" type="selection" width="50">
				</el-table-column>
				<el-table-column v-if="tableDataObj.index" type="index" width="50">
				</el-table-column>
				<template v-for="(item,index) in tableDataObj.columnList">
					<el-table-column v-if="item.slot" :prop="item.prop" :sortable="item.sortable" :label="item.label"
						:min-width="item.width">
						<template slot-scope="scope">
							<slot :name="item.prop" :opera="scope.row" :Index="scope.$index"></slot>
						</template>
					</el-table-column>
					<el-table-column v-if="!item.slot" :prop="item.prop" :sortable="item.sortable" :label="item.label"
						:min-width="item.width">
					</el-table-column>
				</template>
				<el-table-column v-if="tableDataObj.opera" fixed="right" :width="tableDataObj.minWidth" label="操作">
					<template slot-scope="scope">
						<slot name="opera" :opera="scope.row" :Index="scope.$index"></slot>
					</template>
				</el-table-column>
			</el-table>
		</el-col>

		<el-dialog title="提示" :visible="dialogVisible" :show-close='false'>
			<div slot="title">
				{{fromDataObj.title}}
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="cancelDialog()"></i>
			</div>
			<slot v-if="fromDataObj.slot" name="dialog"></slot>
			<el-form v-if="!fromDataObj.slot" ref="form" :model="fromDataObj.formList"
				:label-width="fromDataObj.labelWidth">
				<template v-for="(item,index) in fromDataObj.formList">
					<el-form-item size="small" v-if="item.type == 'text'" :hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)"
						:label="item.label" :prop="index"
						:rules="{required: (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-input v-model="item.value" :placeholder="item.placeholder"></el-input>
					</el-form-item>
					<el-form-item size="small" v-if="item.type == 'password'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required: (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-input type="password" v-model="item.value" :placeholder="item.placeholder"></el-input>
					</el-form-item>
					<el-form-item size="small" v-if="item.type == 'select'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required: (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-select v-model="item.value" :placeholder="item.placeholder">
							<el-option v-for="(itemChild, indexChild) in item.children" :label="itemChild.label"
								:value="itemChild.value"></el-option>
						</el-select>
					</el-form-item>
					<el-form-item size="small" v-if="item.type == 'datePicke'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required: (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-date-picker v-model="item.value" value-format="yyyy-MM-dd HH:mm:ss" align="right" type="date" :placeholder="item.placeholder">
						</el-date-picker>
					</el-form-item>

					<el-form-item size="small" v-if="item.type == 'radio'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required: (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-radio-group v-model="item.value">
							<el-radio v-for="(itemChild, indexChild) in item.children" :label="itemChild.label">
							</el-radio>
						</el-radio-group>
					</el-form-item>
					<el-form-item size="small" v-if="item.type == 'textarea'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required:  (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-input type="textarea" v-model="item.value" :placeholder="item.placeholder"></el-input>
					</el-form-item>
					<el-form-item size="small" v-if="item.type == 'checkbox'"
						:hidden="(dialogStatus == 2 && !item.searchAdv) || (item.modifyShow && dialogStatus == 3)" :label="item.label" :prop="index"
						:rules="{required:  (dialogStatus != 2 && item.require), validator: item.validator, trigger: 'blur' }">
						<el-checkbox-group v-model="item.value">
							<el-checkbox v-for="(itemChild, indexChild) in item.children" :disabled="itemChild.disabled" :checked="itemChild.value" :label="itemChild.label"></el-checkbox>
						</el-checkbox-group>
					</el-form-item>
					<slot v-if="item.type == 'slot'" :name="item.value"></slot>
				</template>
			</el-form>
			<div slot="footer">
				<el-button v-if="dialogStatus == 3" @click="cancelDialog">取消</el-button>
				<el-button v-if="dialogStatus != 3" @click="resetDialog">重置</el-button>
				<el-button v-if="dialogStatus == 1" type="primary" @click="submitData">新增</el-button>
				<el-button v-if="dialogStatus == 2" type="primary" @click="advSearch">搜索</el-button>
				<el-button v-if="dialogStatus == 3" type="primary" @click="saveModify">修改</el-button>
			</div>
		</el-dialog>
	</el-row>
</template>

<script>
	
	import moveSelectBox from "./../../mixins/moveSelectBox.js"
	export default {
		name: 'dataTableList',
		props: {
			tableHeight: {
				type: String,
				default: '660px'
			},
			dialogStatus: {
				type: Number,
				default: 1
			},
			fromDataObj: {
				type: Object,
				default: function() {
					return {

					}
				}
			},
			addData: {
				type: Boolean,
				default: true
			},
			dialogVisible: {
				type: Boolean,
				default: false
			},
			tableDataObj: {
				type: Object,
				default: function() {
					return {
						selection: false,
						index: false,
						columnList: [{
							prop: 'name',
							width: false,
							label: 'name',
							slot: true,
							sortable: true,
						}, {
							prop: 'title',
							width: false,
							label: 'title',
							slot: false,
							sortable: false,
						}, {
							prop: 'time',
							width: false,
							label: 'time',
							slot: false,
							sortable: false,
						}],
						tableData: [{
							name: 'zheng',
							title: "123",
							time: 456
						}]
					}
				},
			},
		},
		mixins: [moveSelectBox],
		data() {
			return {
				sortFile: this.$props.tableDataObj.columnList[0].prop,
				search: ''
			}
		},
		methods: {
			searchSign() {
				this.$emit('getList', {
					searchName: this.search
				});
			},
			resetLoadData() {
				this.$emit('getList', '');
			},
			showDialog(Index) {
				this.$emit('showDialog', Index);
				this.$refs?.form?.clearValidate();
			},
			handleSelectionChange(e) {
				this.$emit('selectionChange', e);
			},
			sortChange(e) {
				this.$emit('getList', {
					SortField: e.prop,
					SortOrder: e.order == 'ascending' ? 'ASC' : 'DESC',
				});
			},
			cancelDialog() {
				this.$emit('showDialog', '');
			},
			resetDialog() {
				let that = this;
				let data = JSON.parse(JSON.stringify(that.fromDataObj.formList));
				that.$emit('resetDialog', function(){
					that.$refs.form.clearValidate();
				});
			},
			advSearch() {
				let data = JSON.parse(JSON.stringify(this.fromDataObj.formList));
				data.advSearch = true;
				this.$emit('getList', data);
			},
			saveModify() {
				let that = this;
				this.$refs.form.validate(function(valid) {
					if (valid) {
						let data = JSON.parse(JSON.stringify(that.fromDataObj.formList));
						that.$emit('saveModifyBtn', data)
					}
				})
			},
			submitData() {
				let that = this;
				this.$refs.form.validate(function(valid) {
					if (valid) {
						let addData = JSON.parse(JSON.stringify(that.fromDataObj.formList));
						that.$emit('addData', addData);
					}
				})
			}
		}
	}
</script>

<style lang="less" scoped>
	.main-title {
		border-bottom: 1px solid #ccc;
		padding-bottom: 15px;
	}

	.search-box {
		text-align: right;
	}
</style>
