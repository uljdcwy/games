<template>
	<el-main class="login">
		<div class="login-from-box">
			<div class="from-title">
				{{title}}
			</div>
			<el-form ref="FormData" :rules="rules" :model="FormData" :label-width="labelWidth">
				<el-form-item label="帐号" prop="account">
					<el-input v-model="FormData.account">
						<i slot="prepend" class="el-icon-user-solid"></i>
						</el-button>
					</el-input>
				</el-form-item>
				<el-form-item label="密码" prop="password">
					<el-input type="password"  @focus="addEnter"  @blur="removeEnter" v-model="FormData.password">
						<i slot="prepend" class="el-icon-lock"></i>
					</el-input>
				</el-form-item>
				<!-- <el-form-item class="checkbox">
					<el-checkbox v-model="FormData.checkbox" class="checkbox-content" label="记住密码" name="type">
					</el-checkbox>
				</el-form-item> -->
				<el-form-item>
					<el-button class="login-btn" type="primary" @click="login">登 录</el-button>
				</el-form-item>
			</el-form>
		</div>
	</el-main>
</template>

<script>
	export default {
		name: 'login',
		props: {
			title: {
				type: String,
				default: ""
			}
		},
		data() {
			return {
				labelWidth: '60px',
				FormData: {
					account: "",
					password: "",
					checkbox: false
				},
				rules: {
					account: [{
						required: true,
						message: '帐号不能为空',
						trigger: 'change'
					}, ],
					password: [{
						required: true,
						message: '密码不能为空',
						trigger: 'change'
					}, ],
				}
			}
		},
		mounted() {
			console.log(this)
		},
		methods: {
			addEnter(e){
				let that = this;
				window.onkeyup = function(e){
					if(e.keyCode == 13){
						that.login();
					}
				}
			},
			removeEnter(e){
				window.onkeyup = null;
			},
			login() {
				let that = this;
				this.$refs['FormData'].validate((valid) => {
					if (valid) {
						let data = JSON.parse(JSON.stringify(this.FormData));
						that.$emit('changeLoginStatus', data)
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			reset() {
				console.log("login reset");
			}
		}
	}
</script>
<style lang="less">
	.login {
		.el-form {}

		.el-form {
			.checkbox {
				margin-top: -10px;

				.el-form-item__content {
					line-height: 20px;
					height: 20px;
				}
			}
		}
	}
</style>

<style lang="scss" scoped>
	.login {
		height: 100%;
		width: 100%;

		.login-from-box {
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translateY(-50%) translateX(-50%);
			max-width: 400px;
			padding: 10px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
			border-radius: 10px;
			width: 100%;

			.from-title {
				text-align: center;
				padding: 10px 0 15px;
				margin-bottom: 20px;
				border-bottom: 1px solid #ccc;

			}

			.login-btn {
				width: 100%;
			}
		}
	}
</style>
