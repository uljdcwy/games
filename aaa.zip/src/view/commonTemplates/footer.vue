<template>
	<div class="pagination-page">
		<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
			:page-sizes="[15, 30, 45, 60]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper"
			:total="total">
		</el-pagination>
	</div>
</template>

<script>
	export default {
		name: "pagination",
		props: {
			total: {
				type: Number,
				default: 0
			},
			pageSize: {
				type: Number,
				default: 10
			},
			currentPage: {
				type: Number,
				default: 0
			}
		},
		data(){
			return {
			}
		},
		methods: {
			handleSizeChange(e){
				this.$emit('getList',{
					pageSize: e,
					currentPage: this.currentPage
				})
			},
			handleCurrentChange(e){
				this.$emit('getList',{
					pageSize: this.pageSize,
					currentPage: (e)
				})
			}
		},
	}
</script>

<style lang="less" scoped>
	.pagination-page{
		text-align: center;
	}
</style>