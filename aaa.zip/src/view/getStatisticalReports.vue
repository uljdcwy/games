<template>
	<el-container>
		<el-main class="get-statistical-reports">
			<data-add-del-mod-find :tableHeight="tableMinHeight" :addData="false" @resetDialog="resetDialog" :tableDataObj="tableDataObj" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus" :fromDataObj="fromDataObj" @getList="getList"
				@showDialog="showDialog">
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList"></main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		DaySumRecordGetList
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				pageSize: 15,
				currentPage: 1,
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "日统计报表",
					searchPlaceholder: "请输入现金充值金额",
					formList: {
						start_sum_day: {
							type: 'datePicke',
							label: "开始日期",
							value: "",
							require: false,
							searchAdv: true
						},
						end_sum_day: {
							type: 'datePicke',
							label: "结束日期",
							value: "",
							require: false,
							searchAdv: true
						},
					},
					labelWidth: '150px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: false,
					selection: false,
					index: false,
					columnList: [{
						prop: 'cash_recharge',
						width: "160px",
						label: '现金充值金额(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'mobile_recharge',
						width: "200px",
						label: '移动支付充值余额(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'discount_recharge',
						width: "160px",
						label: '充值优惠金额(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'deposit',
						width: "160px",
						label: '收取押金金额(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'balance_refund',
						width: "160px",
						label: '余额退款(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'deposit_refund',
						width: "160px",
						label: '押金退款(元)',
						slot: false,
						sortable: true,
					},{
						prop: 'sum_day',
						width: "100px",
						label: '日期',
						slot: false,
						sortable: true,
					}],
					tableData: []
				},
				currentID: ''
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
		},
		methods: {
			resetDialog(){
				let data = this.fromDataObj.formList;
				for(let key in data){
					this.fromDataObj.formList[key].value = '';
				}
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				
				// if(obj.searchName === ''){
				// 	this.searchName = '';
				// }else{
				// 	this.searchName = obj.searchName || this.searchName;
				// }
				
				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize
				
				DaySumRecordGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "balance_refund",
					"SortOrder": obj.SortOrder || "DESC",
					// 'cash_recharge': this.searchName || '',
					'start_sum_day': this.fromDataObj.formList.start_sum_day?.value || '',
					'end_sum_day': this.fromDataObj.formList.end_sum_day?.value || ''
				}).then(function(res){
					let data = res.data.data;
					for(let i = 0;i < data.length; i++){
						data[i].deposit_refund = (data[i].deposit_refund/100).toFixed(2);
						data[i].balance_refund = (data[i].balance_refund/100).toFixed(2);
						data[i].deposit = (data[i].deposit/100).toFixed(2);
						data[i].discount_recharge = (data[i].discount_recharge/100).toFixed(2);
						data[i].mobile_recharge = (data[i].mobile_recharge/100).toFixed(2);
						data[i].cash_recharge = (data[i].cash_recharge/100).toFixed(2);
					}
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index){
				if(index === ''){
					this.dialogVisible = false;
				}else{
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
