<template>
	<el-container>
		<el-main>
			<data-add-del-mod-find :tableHeight="tableMinHeight" :addData="false" @resetDialog="resetDialog"
				:tableDataObj="tableDataObj" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus"
				:fromDataObj="fromDataObj" @getList="getList" @showDialog="showDialog">
				<template slot="oper_type"  slot-scope="row">
					{{row.opera.oper_type  == 1 ?  "挂失中" : "正常"}}
				</template>
			</data-add-del-mod-find>
		</el-main>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		LostRecordGetList
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				total: 0,
				pageSize: 15,
				currentPage: 1,
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "卡片挂失记录",
					searchPlaceholder: "请输入用户名称",
					formList: {
						user_name: {
							type: 'text',
							label: "用户名称",
							value: "",
							searchAdv: true
						},
						start_oper_time: {
							type: 'datePicke',
							label: "开始时间",
							value: "",
							searchAdv: true
						},
						end_oper_time: {
							type: 'datePicke',
							label: "结束时间",
							value: "",
							searchAdv: true
						}
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: false,
					selection: false,
					index: false,
					columnList: [{
							prop: 'user_name',
							width: false,
							label: '用户名称',
							slot: false,
							sortable: true,
						},
						{
							prop: 'oper_type',
							width: false,
							label: '卡状态',
							slot: true,
							sortable: true,
						},
						{
							prop: 'oper_time',
							width: false,
							label: '操作时间',
							slot: false,
							sortable: true
						}
					],
					tableData: []
				},
				currentID: ''
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
		},
		methods: {
			resetDialog() {
				let data = this.fromDataObj.formList;
				for (let key in data) {
					this.fromDataObj.formList[key].value = '';
				}
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if (obj.advSearch) {
					this.searchName = obj.user_name.value;
				}else if(obj.searchName === '' || obj.searchName){
					this.resetDialog();
					this.searchName = obj.searchName;
				}

				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize

				LostRecordGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "user_name",
					"SortOrder": obj.SortOrder || "DESC",
					'user_name': this.searchName || '',
					'start_oper_time': this.fromDataObj.formList.start_oper_time?.value || '',
					'end_oper_time': this.fromDataObj.formList.end_oper_time?.value || ''
				}).then(function(res) {
					that.tableDataObj.tableData = res.data.data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if (index === '') {
					this.dialogVisible = false;
				} else {
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
