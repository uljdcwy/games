<template>
	<el-container>
		<el-main class="table-show">
			<data-add-del-mod-find :tableHeight="tableMinHeight" :addData="false" @resetDialog="resetDialog"
				:tableDataObj="tableDataObj" :dialogVisible='dialogVisible' :dialogStatus="dialogStatus"
				:fromDataObj="fromDataObj" @getList="getList" @showDialog="showDialog">
				<template slot="image" slot-scope="row">
					
					<el-button size="small" style="position:absoute;top:50%;left:50%" :disabled="!row.opera.image" @click="lookImage(row)">查看</el-button>
				</template>
			</data-add-del-mod-find>
		</el-main>
		<el-dialog style="text-align: center;" :close-on-click-modal="false" :visible.sync="showImageStatus" :show-close='false'>
			<div slot="title">
				查看照片
				<i class="el-icon-close" style="position: absolute;top: 10px;right: 10px;cursor: pointer;"
					@click="showImageStatus = false"></i>
			</div>
			<el-image :src="photoUrl" ></el-image>
		</el-dialog>
		<el-footer height="40px">
			<main-footer :total="total" :currentPage="currentPage" :pageSize="pageSize" @getList="getList">
			</main-footer>
		</el-footer>
	</el-container>
</template>

<script>
	import {
		ConsumeRecordGetList
	} from "./../http/http.js"
	import mainFooter from "./commonTemplates/footer.vue";
	import dataAddDelModFind from "./commonTemplates/dataAddDelModFind.vue"
	export default {
		components: {
			mainFooter,
			dataAddDelModFind
		},
		data() {
			return {
				dialogVisible: false,
				showImageStatus: false,
				total: 0,
				pageSize: 15,
				currentPage: 1,
				photoUrl: '',
				searchName: '',
				fromDataObj: {
					opera: false,
					title: "消费记录表",
					searchPlaceholder: "请输入用户名称",
					formList: {
						user_name: {
							type: 'text',
							label: "用户名称",
							value: "",
							require: true,
							msg: "请输入用户名称",
							searchAdv: true
						},
						card_id: {
							type: 'text',
							label: "卡ID",
							value: "",
							require: true,
							msg: "请输入卡ID",
							searchAdv: true
						},
						device_name: {
							type: 'text',
							label: "设备名称",
							value: "",
							require: true,
							msg: "请输入设备名称",
							searchAdv: true
						},
						start_oper_time: {
							type: 'datePicke',
							label: "开始时间",
							value: "",
							searchAdv: true
						},
						end_oper_time: {
							type: 'datePicke',
							label: "结束时间",
							value: "",
							searchAdv: true
						}
					},
					labelWidth: '120px'
				},
				dialogStatus: 1,
				tableDataObj: {
					opera: false,
					selection: false,
					index: false,
					columnList: [{
							prop: 'user_name',
							width: "160px",
							label: '用户名称',
							slot: false,
							sortable: true,
						},
						// {
						// 	prop: 'dept_name',
						// 	width: false,
						// 	label: '部门名称',
						// 	slot: false,
						// 	sortable: false,
						// },
						{
							prop: 'card_id',
							width: "120px",
							label: '卡ID',
							slot: false,
							sortable: true,
						}, {
							prop: 'money',
							width: "140px",
							label: '金额（元）',
							slot: false,
							sortable: true,
						}, {
							prop: 'discount_money',
							width: "180px",
							label: '折扣金额（元）',
							slot: false,
							sortable: true,
						}, {
							prop: 'discount',
							width: "140px",
							label: '折扣（元）',
							slot: false,
							sortable: true,
						}, {
							prop: 'balance',
							width: "120px",
							label: '结余（元）',
							slot: false,
							sortable: true,
						}, {
							prop: 'device_name',
							width: "160px",
							label: '设备名称',
							slot: false,
							sortable: true,
						}, {
							prop: 'oper_time',
							width: "160px",
							label: '操作时间',
							slot: false,
							sortable: false,
							sortable: true,
						}, {
							prop: 'image',
							width: "120px",
							label: '头像',
							slot: true,
							sortable: true,
						}],
					tableData: []
				},
				currentID: ''
			}
		},
		mounted() {
			// 获取当前列表数据
			this.getList();
		},
		methods: {
			lookImage(row){
				console.log(row.opera.image,"row123456",this.$http.options.root + '/' + row.opera.image)
				this.showImageStatus = true;
				this.photoUrl = this.$http.options.root + '/' + row.opera.image
			},
			resetDialog() {
				let data = this.fromDataObj.formList;
				for (let key in data) {
					this.fromDataObj.formList[key].value = '';
				}
			},
			getList(obj) {
				let that = this;
				obj = obj || {};
				// 点击了高级搜索
				if (obj.advSearch) {
					this.searchName = obj.user_name.value;
				}else if(obj.searchName === '' || obj.searchName){
					this.resetDialog();
					this.searchName = obj.searchName;
				}

				that.currentPage = obj.currentPage || that.currentPage
				that.pageSize = obj.pageSize || that.pageSize

				ConsumeRecordGetList({
					"PageIndex": (that.currentPage - 1),
					"PageSize": that.pageSize,
					"SortField": obj.SortField || "user_name",
					"SortOrder": obj.SortOrder || "DESC",
					'user_name': this.searchName || '',
					"card_id": this.fromDataObj.formList.card_id?.value || '',
					"device_name": this.fromDataObj.formList.device_name?.value || '',
					"end_oper_time": this.fromDataObj.formList.end_oper_time?.value || '',
					"start_oper_time": this.fromDataObj.formList.start_oper_time?.value || ''
				}).then(function(res) {
					let data = res.data.data;
					for (let i = 0; i < data.length; i++) {
						data[i].money = (data[i].money / 100).toFixed(2);
						data[i].discount_money = (data[i].discount_money / 100).toFixed(2);
						data[i].discount = (data[i].discount / 100).toFixed(2);
						data[i].balance = (data[i].balance / 100).toFixed(2);
					}
					that.tableDataObj.tableData = data;
					that.total = res.data.count;
					that.dialogVisible = false;
				})
			},
			showDialog(index) {
				if (index === '') {
					this.dialogVisible = false;
				} else {
					this.dialogStatus = index;
					this.dialogVisible = true;
				}
				// console.log(this.dialogStatus,'this.dialogStatus');
			},
		},
	}
</script>

<style>
	.el-footer {
		border-top: 1px solid #ccc;
		padding-top: 5px !important;
	}
</style>
