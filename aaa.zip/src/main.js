import Vue from 'vue'
import App from './App.vue'
import vueResource from "vue-resource"
import ElementUI from 'element-ui'
import './css/theme.scss';
import router from "./router/router.js"
import  store from  './store/index'
import "./css/common.scss";



Vue.use(vueResource);
Vue.use(ElementUI);

Vue.http.options.root = "http://localhost:8080";
Vue.http.options.timeout = 10000;

Vue.prototype.tableMinHeight = '820px';

// 加载模态初始为空
let loadingStatus = "";

// 配制拦截器
Vue.http.interceptors.push((request, next) => {
		
	//登录成功后将后台返回的TOKEN在本地存下来,每次请求从sessionStorage中拿到存储的TOKEN值 
	
	let token = store.state.token;
	
	if (token && request.url != 'Oper/Login') {
		//如果请求时TOKEN存在,就为每次请求的headers中设置好TOKEN,后台根据headers中的TOKEN判断是否放行 
		request.headers.set('token', token);
	}
	
	let requestBody = request.body;
	
	for(let key in requestBody){
		if(requestBody[key] === '' && key != 'face_url'){
			delete requestBody[key];
		}
	};
	// 在非获取数据列表时开启加载模态
	if(requestBody && !requestBody.PageSize || !loadingStatus){
		loadingStatus = ElementUI.Loading.service({ fullscreen: true });
	}
	
	next((response) => {
		if(!response.ok && !response.data){
			loadingStatus.close();
			loadingStatus = null;
			ElementUI.Message.error('连接服务器失败');
		}else if(response.data.msg && response.data.code != 1){
			loadingStatus.close();
			loadingStatus = null;
			if(response.data.msg.search('token') > -1){
				store.state.token = "";
			}
			ElementUI.Message.warning(response.data.msg);
		};
		
		response.loadingStatus = loadingStatus;
		
		// 在getList 时关闭加载模态
		if(requestBody && requestBody.PageSize){
			loadingStatus.close();
			loadingStatus = null;
		}
		return response;
	});
});

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
  router,
  store
}).$mount('#app')
