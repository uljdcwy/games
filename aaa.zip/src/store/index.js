import Vue from "vue";
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
	state: {
		roleData: "",
		token: "",
		currentComponents: "showSN",
		loginData: ""
	},
	mutations: {
		setRoleData(state, roleData) {
			state.roleData = roleData
		},
		setToken(state, token) {
			state.token = token
		},
		setCurrentComponents(state, currentComponents) {
			state.currentComponents = currentComponents
		},
		setLoginData(state, loginData) {
			state.loginData = loginData
		},
		loginOutState(state, login){
			state.roleData = "";
			state.token = "";
			state.currentComponents = "";
			state.loginData = "";
		}
	}
});

export default store;
